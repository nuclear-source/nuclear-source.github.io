<?php defined('INDEXPATH') OR exit('No direct script access allowed');

/*****************
 * BOOT FRAMEWORK
 * *************/
$bootstrap   = parse_ini_file(".conf", true);
if(isset($bootstrap['APPconfig']) && is_file(__DIR__.$bootstrap['APPconfig']))	
	$config = parse_ini_file(__DIR__.$bootstrap['APPconfig'], true);
else	
	$config = $bootstrap['config'];
/*****************
 * BOOT DEBUG
 * *************/
if(!isset($config['appDEFAULT']) || 
   !isset($config['appFOLDER' ]) || 
   !isset($config['appVERSION']) ||
   !isset($config['appASSETS' ]) ){
	echo 'NuclearCMS - Boot::ERROR (line18)';die();}
if(!isset($bootstrap['system']['PATH'])){
	echo 'NuclearCMS - System::PATH (line20)';die();}

/*****************
 * CONFIG APPLICATION
 * *************/
$appDEFAULT  = $config['appDEFAULT']; 
$appFOLDER   = $config['appFOLDER'];  
$appVERSION  = $config['appVERSION'];
$appASSETS   = $config['appASSETS'];
$inc         = $bootstrap['system']['PATH'];
 
/*****************
 * RUN FRAMEWORK
 * *************/
if(isset($bootstrap['appFORCE'])) //force or ignore module:error
	$FORCE = true;
if(isset($config['appMODULES'])) //test modules
	require_once 'nuclear.run.php';
else 
	$default=true;  //define as default nuclear
	
/*****************
 * START SYSTEM
 * *************/
require_once $inc.'system.start.php';



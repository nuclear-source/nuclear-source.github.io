<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Nuclear_dao extends Nuclear_crud
{
	
	public $up=true;
	/**
	 *
	 * DEFINE TABLE
	 *  crud->table();
	 */
	function _construct()
	{
		$this->table($this->tableNAME);
		$this->prefix=$this->colPREFIX;
	}
	
	function _getall($select='',$order=array(),$limit='')
	{
		if($this->up)
			$select=strtoupper($select);
		if($this->prefix!='')
			$select=_restring($select,$this->prefix);
		$query=$this->read($select,array(),$order,$limit);
		if($this->prefix!='')
			return dbrange($query,$this->prefix);
		else 
			return $query;
	}
	
	function _getwhere($select='',$where=array(),$order=array(),$limit='')
	{
		if($this->up){$select=strtoupper($select);}
		$select=_restring($select,$this->prefix);
		$where=_rearray($where,$this->prefix);
		$query=$this->read($select,$where,$order,$limit);
		return dbrange($query,$this->prefix);
	}
	

	function _search($table='',$search_term='')
	{
	
		$this->db->select('*');
		$this->db->from($table);
		$this->db->like($this->prefix.'TITLE', $search_term);
		$this->db->or_like($this->prefix.'SUBTITLE', $search_term);
		$this->db->or_like($this->prefix.'KEYWORDS', $search_term);
		$this->db->or_like($this->prefix.'TEXT', $search_term);
		
		$this->db->join($table.'_groups',$table.'_groups.groupsID = '.$table.'.'.$this->prefix.'GROUPS');
		
		$query = $this->db->get()->result();
		foreach($query as $key=>$val)
		{
			$val->group=$val->groupsSLUG;
			unset($val->groupsSLUG);
		}
		return dbrange($query,$this->prefix);
	}
	
	
	
	
}
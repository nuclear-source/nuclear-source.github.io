<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Nuclear_init extends Nuclear_model
{
	function get_groups($slug='catalogue')
	{
		$this->db->select('*');
		$query2 = $this->db->get($slug.'_groups')->result();
		$table['results']=$this->dbrange($query2);
		return $table;
	}
}
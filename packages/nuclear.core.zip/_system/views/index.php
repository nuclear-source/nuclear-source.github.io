<?=$head?>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script>window.jQuery || document.write('<script src="<?=base_url()?>assets/js/jquery-1.11.2.min.js"><\/script>')</script>
	<body>    
	    <?=$navbar;?>   
	    <?=$partial;?>
	    <?=$footer;?>
		<?=$scripts;?>
    </body>
</html>

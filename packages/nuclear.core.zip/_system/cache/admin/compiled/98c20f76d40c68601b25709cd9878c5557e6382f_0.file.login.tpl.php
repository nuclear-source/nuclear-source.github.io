<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:29:43
  from "X:\xampp\htdocs\_dev\projects\espaco\apps\_nuclear\_apps\admin\themes\default\partials\user\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea0c7038b42_77925434',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98c20f76d40c68601b25709cd9878c5557e6382f' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\espaco\\apps\\_nuclear\\_apps\\admin\\themes\\default\\partials\\user\\login.tpl',
      1 => 1463591278,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea0c7038b42_77925434 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_assignInScope('subheading', t('login_subheading'));
$_smarty_tpl->_assignInScope('heading', t('login_heading'));
$_smarty_tpl->_assignInScope('loginlab', t('login_identity_label'));
$_smarty_tpl->_assignInScope('passlab', t('login_password_label'));
$_smarty_tpl->_assignInScope('formopen', form_open("login"));
$_smarty_tpl->_assignInScope('forminput', form_input($_smarty_tpl->tpl_vars['identity']->value));
$_smarty_tpl->_assignInScope('forminput2', form_input($_smarty_tpl->tpl_vars['password']->value));
$_smarty_tpl->_assignInScope('formsubmit', form_submit('success',lang('login_submit_btn'),"class='btn btn-success' style='width:100%'"));
$_smarty_tpl->_assignInScope('formclose', form_close());
?>

		<div class="col-sm-6 col-sm-offset-3">
			<div class="panel panel-default">
			   <div class="panel-heading">
					 <h2 class="text-center" style="font-weight:bold" >api.espaco</h2>
					</div>
					<div id="infoMessage ">
						<?php if (isset($_smarty_tpl->tpl_vars['message']->value)) {?>
						<div class="alert alert-danger" role="alert"><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</div>
						<?php }?>
					</div>
				  	<div class="panel-body">
					<?php echo $_smarty_tpl->tpl_vars['formopen']->value;?>

					  <p>
					    <?php echo $_smarty_tpl->tpl_vars['loginlab']->value;?>

					  	<?php echo $_smarty_tpl->tpl_vars['forminput']->value;?>

					  </p>
					  <p>
					  	<?php echo $_smarty_tpl->tpl_vars['passlab']->value;?>

					  	<?php echo $_smarty_tpl->tpl_vars['forminput2']->value;?>

					  </p>
					  <p><?php echo $_smarty_tpl->tpl_vars['formsubmit']->value;?>
</p>
					<?php echo $_smarty_tpl->tpl_vars['formclose']->value;?>

			</div>
			  <div class="panel-footer">Need Help? <a href="mailto:webmaster@espaco.pt" class="">webmaster@espaco.pt</a>
              
				</div>
				
		</div>
<style>
/* CSS used here will be applied after bootstrap.css */

body { 
 background: url('<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
uploads/lg/bmpshbttn__date__1463589376.jpg') no-repeat center center fixed; 
 -webkit-background-size: cover;
 -moz-background-size: cover;
 -o-background-size: cover;
 background-size: cover;
}

.panel-default {
 opacity: 0.95;
 margin-top:30%;
}
.form-group.last {
 margin-bottom:0px;
}
</style><?php }
}

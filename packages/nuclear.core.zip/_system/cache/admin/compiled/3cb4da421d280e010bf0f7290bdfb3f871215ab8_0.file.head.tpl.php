<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:29:42
  from "X:\xampp\htdocs\_dev\projects\espaco\apps\_nuclear\_apps\admin\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea0c6d0c431_85331793',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3cb4da421d280e010bf0f7290bdfb3f871215ab8' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\espaco\\apps\\_nuclear\\_apps\\admin\\themes\\default\\common\\head.tpl',
      1 => 1463647800,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea0c6d0c431_85331793 (Smarty_Internal_Template $_smarty_tpl) {
?>
<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/bootnuclear.css"        >	
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/metismenu.min.css"      >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/responsive-layouts.css" >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/uploadfile.css"         >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/datatables.min.css"   >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/jqueryFileTree.css"     >		
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/manager.css"><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:32:25
  from "X:\xampp\htdocs\_dev\projects\_nuclear\_apps\admin\themes\default\common\navbar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea169b52d04_23799409',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8f0982f0a0d1e3f48cc8bd4968643b7a34c81bb4' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\_apps\\admin\\themes\\default\\common\\navbar.tpl',
      1 => 1460680723,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea169b52d04_23799409 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <nav class="navbar navbar-inverse navbar-fixed-top responsive " style="z-index:90">
		      <div class="container-fluid">
		          <div class="navbar-header">
		            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		              <span class="sr-only">Toggle navigation</span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		              <span class="icon-bar"></span>
		            </button>
		            <a class="navbar-brand" href="<?php echo PUBLICPATH;
echo MODULECALL;?>
/">
		            <span>Nuclear</span>ADMIN</a>
		          </div>
		          <div id="navbar" class="navbar-collapse collapse">
		            <ul class="nav navbar-nav">
		            </ul>
		            <ul class="nav navbar-nav navbar-right">
		              	<li style="background:#d9a300"><a href="<?php echo PUBLICPATH;?>
" target="_blank"><i class="fa fa-eye"></i> View SITE</a></li>
							     
		              <?php if (isset($_smarty_tpl->tpl_vars['verisset']->value)) {?><li class="dropdown">
		                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My Profile <span class="caret"></span></a>
		                <ul class="dropdown-menu">
		                  <li><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
user/profiles">Profile</a></li>
		                  <li><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
user/password">Change Passoword</a></li>
		                </ul>
		              </li>
		              <?php }?>
		              </ul>
		          </div>
		      </div>
		  </nav><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 01:18:39
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms-nodb\themes\default\partials\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_5767284fa132c5_13025589',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '25d1ddc3538585b8a8d0c2e80ec72deb20797bd9' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms-nodb\\themes\\default\\partials\\home.tpl',
      1 => 1466376009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5767284fa132c5_13025589 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="container-fluid wow fadeIn nowrap"  data-wow-duration="1.3s"  data-wow-delay="0.7s" >

	<div class="parallax-window"  data-position-y="center" data-parallax="scroll" data-image-src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
lg/<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesIMG;?>
">

	

	</div>

</section>



<section>

	<div class="container">

		<div class="row">

		<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


	</div>

</section><?php }
}

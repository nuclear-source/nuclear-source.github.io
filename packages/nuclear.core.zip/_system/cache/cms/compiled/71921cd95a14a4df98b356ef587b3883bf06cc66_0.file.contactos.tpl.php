<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:44:45
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\pereira\partials\contactos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_5767205d9f0866_97037589',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '71921cd95a14a4df98b356ef587b3883bf06cc66' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\pereira\\partials\\contactos.tpl',
      1 => 1465957315,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5767205d9f0866_97037589 (Smarty_Internal_Template $_smarty_tpl) {
?>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3026.169887278094!2d-7.936892784596337!3d40.670225579336446!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd2337c1645a64ed%3A0x366e1ce4af951da2!2sUrbaniza%C3%A7%C3%A3o+Colina+do+Parque%2C+3510+Viseu!5e0!3m2!1spt-PT!2spt!4v1460689712937"  

width="100%" height="400" style="margin-top:-50px;border:0" frameborder="0"  allowfullscreen></iframe>



<section style="background:#fff;color:#000">

	<div class="container">

		<div class="row"><br/>

		<div class="col-sm-1">

		</div>

		<div class="col-sm-5">

		<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


		</div>

		<div class="col-sm-5">

		<iframe src="https://www.google.com/maps/embed?pb=!1m0!3m2!1spt-PT!2spt!4v1460690013234!6m8!1m7!1sUd6DnN25EpF1MdNxqSclUw!2m2!1d40.6697345!2d-7.9310379!3f334.2083673036735!4f-2.9796723294967933!5f2.56071257560726"

		 width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>

		</div>

		</div>

	</div>

</section>

<section style="clear:both"><br/></section><?php }
}

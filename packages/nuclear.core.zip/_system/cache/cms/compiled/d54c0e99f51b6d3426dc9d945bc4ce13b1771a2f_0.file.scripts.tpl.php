<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:40:51
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671f73d5cd29_56426576',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd54c0e99f51b6d3426dc9d945bc4ce13b1771a2f' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\common\\scripts.tpl',
      1 => 1466376049,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671f73d5cd29_56426576 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Bootstrap Core JavaScript -->

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/nuclear.bootstrap.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/cookieconsent.js"><?php echo '</script'; ?>
>    

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/theme.js"><?php echo '</script'; ?>
>  

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/paralax/parallax.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
>

	$(".fancybox").fancybox();

	window.cookieconsent_options = { learnMore: 'Ler Mais', link: 'http://example.com/cookiepolicy' };

	<?php echo '</script'; ?>
>	   <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 01:12:14
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms-nodb\themes\pereira\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576726ceb702b2_80257025',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c0ac5229018e4ac944c808e33c2ee7b5be2b7499' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms-nodb\\themes\\pereira\\common\\scripts.tpl',
      1 => 1466376431,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576726ceb702b2_80257025 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Bootstrap Core JavaScript -->

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/nuclear.bootstrap.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/cookieconsent.js"><?php echo '</script'; ?>
>    

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/theme.js"><?php echo '</script'; ?>
>  

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/paralax/parallax.js"><?php echo '</script'; ?>
>

	

			<style>

			.list .item{

					background:#fff;margin:2px 10px;line-height:25px}

			.list .item span{

					color:#000;margin-left:10px;font-size:11px;}

			.list .item a{

					color:#fff;margin-left:10px;text-decoration:none;font-size:14px;float:right;margin:2px}

	

.btn {

border:none;

}

.btn:hover, .btn:focus,.btn:active {

border:none;

}

</style>

			

			<?php echo '<script'; ?>
>

			function cart(func, key)

			{



				alert(func+key);

				}

			<?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
>

	$(".fancybox").fancybox();

	window.cookieconsent_options = { learnMore: 'Ler Mais', link: 'http://example.com/cookiepolicy' };

    function add_cartx()

    {

    		$.get( "<?php echo base_url();?>
shop/cart/add/", function( data ) {

    		  $( ".result" ).html( data );

    		  alert( "Load was performed." +data);

    		});

    }

function view_cart()

{

		$.get( "<?php echo base_url();?>
shop/cart/view/", function( data ) {

		  $( ".result" ).html( data );

		  alert( "Load was performed." +data);

		});

}



$('.add-to-cart').on('click', function () {



   

	    

        var cart = $('.shopping-cart');

        var imgtodrag = $(this).parent('.item').find("img").eq(0);

        if (imgtodrag) {

            var imgclone = imgtodrag.clone()

                .offset({

                top: imgtodrag.offset().top,

                left: imgtodrag.offset().left

            })

                .css({

                'opacity': '0.5',

                    'position': 'absolute',

                    'height': '150px',

                    'width': '150px',

                    'z-index': '100'

            })

                .appendTo($('body'))

                .animate({

                'top': cart.offset().top + 10,

                    'left': cart.offset().left + 10,

                    'width': 75,

                    'height': 75

            }, 1000, 'easeInOutExpo');

            

            setTimeout(function () {

            }, 1500);



            imgclone.animate({

                'width': 0,

                    'height': 0

            }, function () {

                $(this).detach()

            });



        }



    });



function cart(func,id)

{

	event.preventDefault();

	event.stopPropagation();

	if(func=='delete'){

		$.get( "<?php echo base_url();?>
shop/cart/delete/"+id, function( data ) {

			$('.list').empty();

				$('.list').append(data);

			});

		}

	



}



function add_cart(id,slug)

{

	

	event.preventDefault();

event.stopPropagation();

$.get( "<?php echo base_url();?>
shop/cart/add/"+id+"/"+slug, function( data ) {

	$('.list').empty();

		$('.list').append(data);

	});

/*  VERIFICAR SE ESTÁ a ESCREVER INPUTS  */

//setConfirmUnload(true);

/*****************************/



}

	<?php echo '</script'; ?>
>	   <?php }
}

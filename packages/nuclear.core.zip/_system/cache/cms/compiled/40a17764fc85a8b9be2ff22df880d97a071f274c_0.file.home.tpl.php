<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:40:11
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\partials\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671f4bbec183_14480914',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '40a17764fc85a8b9be2ff22df880d97a071f274c' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\partials\\home.tpl',
      1 => 1466376009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671f4bbec183_14480914 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="container-fluid wow fadeIn nowrap"  data-wow-duration="1.3s"  data-wow-delay="0.7s" >

	<div class="parallax-window"  data-position-y="center" data-parallax="scroll" data-image-src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
lg/<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesIMG;?>
">

	

	</div>

</section>



<section>

	<div class="container">

		<div class="row">

		<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


	</div>

</section><?php }
}

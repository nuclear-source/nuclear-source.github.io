<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:41:57
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\partials\contactos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671fb58676f0_73883957',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6cd08165eb6086054e8e0567159c1f36e2e595d4' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\partials\\contactos.tpl',
      1 => 1465957307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671fb58676f0_73883957 (Smarty_Internal_Template $_smarty_tpl) {
?>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3150913.0467581935!2d-10.096926256082423!3d39.53562099288933!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xb32242dbf4226d5%3A0x2ab84b091c4ef041!2sPortugal!5e0!3m2!1spt-PT!2spt!4v1460333875477" 

width="100%" height="400" style="margin-top:-50px;border:0" frameborder="0"  allowfullscreen></iframe>

<section style="background:#fff;color:#000">

	<div class="container">

		<div class="row">

			<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


		</div>

	</div>

</section>

<section style="clear:both"><br/></section><?php }
}

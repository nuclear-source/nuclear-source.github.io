<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:29:31
  from "X:\xampp\htdocs\_dev\projects\espaco\apps\_nuclear\_nuclear\themes\default\partials\default.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea0bb98e968_37464271',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6b495c152387f1d090258e70535f56d6b900a9b5' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\espaco\\apps\\_nuclear\\_nuclear\\themes\\default\\partials\\default.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea0bb98e968_37464271 (Smarty_Internal_Template $_smarty_tpl) {
?>

<section style="margin-top:120px" >
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
				  <div class="panel-heading">Welcome to default application</div>
				  <div class="panel-body">
				  <?php if (count($_smarty_tpl->tpl_vars['apps']->value) == 0) {?> You dont have any application<br/>to create edit file _apps/config.xml
				  <?php } else { ?>
				  You dont have <?php echo count($_smarty_tpl->tpl_vars['apps']->value);?>
 application<br/>to make changes edit file _apps/config.xml
				  <?php }?>
				  </div>
				  <div class="col-sm-6">				  			 
				  <pre>&lt!--Default Application config-code-->
    &ltapp>
       &lturi>appname&lt/uri> 
       &ltname>appname&lt/name> 
       &lticon>fa fa-home&lt/icon>
       &ltpermission>0&lt/permission>   <!-- USE: 0-public, 1-private-->
    &lt/app>
		 </pre>
				  </div>
				    <div class="col-sm-6">
				    <?php if (count($_smarty_tpl->tpl_vars['apps']->value) > 0) {?>
				    if You see this please define DEFAULT_APP
				    	APPLICATIONS:<br/>
					   <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['apps']->value, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_0_saved = $_smarty_tpl->tpl_vars['val'];
?>
					  <a href="<?php echo base_url();
echo $_smarty_tpl->tpl_vars['val']->value->uri;?>
"><b><?php echo $_smarty_tpl->tpl_vars['val']->value->name;?>
</b></a>					   <br/>
					   <?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
				     <?php }?>
				    </div>
		<div style="clear:both"></div>
		
				</div>
		</div>
		
	</div>
</section><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:35:40
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-core\_nuclear\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea22c8b04d7_33067966',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b4fb5fc3c7df77416c1ab8d453cc3a6c63f2dbd6' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-core\\_nuclear\\themes\\default\\common\\head.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea22c8b04d7_33067966 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title><?php echo strtoupper($_smarty_tpl->tpl_vars['content']->value->title);
echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 - <?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
 </title>
     <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->subtitle;?>
 <?php echo $_smarty_tpl->tpl_vars['project']->value['description'];?>
">
     <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->keywords;?>
">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" href="data:image/x-icon;base64,<?php echo $_smarty_tpl->tpl_vars['favicon']->value;?>
" type="image/x-icon" />
   	 <link rel="stylesheet" href="https://uxcdn.firebaseapp.com/css/nuclear.css"> 
   	 <style><?php echo $_smarty_tpl->tpl_vars['styles']->value;?>
.zoom:after { background:url(<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/uploads/icon.png);}#ex1 img:hover { cursor: url(<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/uploads/grab.cur), default;}</style>
   <?php echo '<script'; ?>
 src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"><?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="https://uxcdn.firebaseapp.com/jquery-1.11.2.min"><\/script>')<?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/static/js/jquery-1.11.2.min.js"><\/script>')<?php echo '</script'; ?>
>

   
         <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-24 15:47:52
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\_nuclear\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57445b8873ea73_92396345',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '868a2d1003a88b727c990102386abe49743786eb' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\_nuclear\\themes\\default\\common\\footer.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57445b8873ea73_92396345 (Smarty_Internal_Template $_smarty_tpl) {
}
}

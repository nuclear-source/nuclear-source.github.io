<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-17 20:35:35
  from "X:\xampp\htdocs\_dev2\nuclear\nuclear-custom\web\themes\default\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576442f7b32309_55111320',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75305e3009808fc1dfacc5eecf96a983f69d5ae8' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\nuclear-custom\\web\\themes\\default\\common\\scripts.tpl',
      1 => 1463729879,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576442f7b32309_55111320 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <?php echo '<script'; ?>
 src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"><?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/jquery-1.11.2.min.js"><\/script>')<?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"><?php echo '</script'; ?>
><?php }
}

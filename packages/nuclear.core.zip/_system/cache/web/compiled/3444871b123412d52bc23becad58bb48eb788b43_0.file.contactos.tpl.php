<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-23 19:52:12
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\partials\contactos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_5743434c856600_49052017',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3444871b123412d52bc23becad58bb48eb788b43' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\partials\\contactos.tpl',
      1 => 1464025929,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5743434c856600_49052017 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section style="margin-top:20px" >
	<div class="container">
		<div class="row">
		    <h1 class="page-header">Contactos</h1>
			<div class="panel panel-default">
				  <div class="panel-heading">
				     <h2>:: Contact_form</h2>
				      <h4>Preecha o formulário</h4>
				  </div>
				  <div class="panel-body">
				      <p>send Mensage</p>
		            <div style="clear:both"></div>
		          </div> 
    		</div>
		</div>
	</div>
</section><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-23 20:50:59
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\_apps\web\themes\default\common\navbar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_574351133b0527_71275910',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c08f44362eef723588cac6df2fadd240cbb6ed5f' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\_apps\\web\\themes\\default\\common\\navbar.tpl',
      1 => 1463733731,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_574351133b0527_71275910 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top  ">
        <div class="container-fluid">
        <div class="container " >
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
          		<a class="navbar-brand " href="<?php echo base_url();?>
" style="color:#fff"><img src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
img/nuclear-web.png" height="30px"/></a>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
             <ul class="nav navbar-nav navbar-right">     
               <li class="<?php if ($_smarty_tpl->tpl_vars['partial']->value == 'home') {?>active<?php }?>"><a href="<?php echo base_url();?>
"><i class="glyphicon glyphicon-home"></i> Home</a></li>
               <li class="<?php if ($_smarty_tpl->tpl_vars['partial']->value == 'modulos') {?>active<?php }?>"><a href="<?php echo base_url();?>
page/modulos"><i class="glyphicon glyphicon-th-large"></i> Módulos</a></li>
               <li class="<?php if ($_smarty_tpl->tpl_vars['partial']->value == 'contactos') {?>active<?php }?>"><a href="<?php echo base_url();?>
page/contactos"><i class="glyphicon glyphicon-envelope"></i> Contactos</a></li>
            </ul>
            </div>
        </div>
        </div>
    </nav>
<div style="height:50px"></div><?php }
}

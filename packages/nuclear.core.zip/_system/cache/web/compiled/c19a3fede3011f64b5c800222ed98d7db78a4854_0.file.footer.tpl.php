<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-17 20:35:35
  from "X:\xampp\htdocs\_dev2\nuclear\nuclear-custom\web\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576442f7a6dae8_40894188',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c19a3fede3011f64b5c800222ed98d7db78a4854' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\nuclear-custom\\web\\themes\\default\\common\\footer.tpl',
      1 => 1463733811,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576442f7a6dae8_40894188 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container-fluid well">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h1>NUCLEARCMS</h1>
                <p>DEscrição do projecto nuclear</p>
                <p>Projeto do nuclear</p>
            </div>
            <div class="col-sm-3 ">
                <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                  <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
        </div>
    </div>
</div><?php }
}

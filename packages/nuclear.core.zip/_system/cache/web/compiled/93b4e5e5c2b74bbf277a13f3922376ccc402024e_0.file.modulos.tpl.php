<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-17 20:17:58
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\web\themes\default\partials\modulos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57643ed657ea10_23968467',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '93b4e5e5c2b74bbf277a13f3922376ccc402024e' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\web\\themes\\default\\partials\\modulos.tpl',
      1 => 1463730009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57643ed657ea10_23968467 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section style="margin-top:20px" >
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
				  <div class="panel-heading">Welcome to default application</div>
				  <div class="panel-body">
		          <div style="clear:both"></div>
    		</div>
		</div>
	</div>
</section><?php }
}

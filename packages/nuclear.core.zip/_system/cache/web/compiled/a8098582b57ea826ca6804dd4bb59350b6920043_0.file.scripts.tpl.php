<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-24 16:20:54
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\web\themes\default\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_574463467c4d42_40164309',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8098582b57ea826ca6804dd4bb59350b6920043' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\web\\themes\\default\\common\\scripts.tpl',
      1 => 1463729879,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_574463467c4d42_40164309 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <?php echo '<script'; ?>
 src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"><?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/jquery-1.11.2.min.js"><\/script>')<?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"><?php echo '</script'; ?>
><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 09:40:10
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\partials\modulos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ebf5a81c4c7_05730588',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '01551a47c785c3e59c1b3278a5c3588f56470e90' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\partials\\modulos.tpl',
      1 => 1463730009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ebf5a81c4c7_05730588 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section style="margin-top:20px" >
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
				  <div class="panel-heading">Welcome to default application</div>
				  <div class="panel-body">
		          <div style="clear:both"></div>
    		</div>
		</div>
	</div>
</section><?php }
}

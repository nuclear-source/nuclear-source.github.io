<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 10:43:32
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ece34aab342_00533254',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '13d8d50eb36add13e843c45fb895bdd755d88924' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\common\\footer.tpl',
      1 => 1463733811,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ece34aab342_00533254 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container-fluid well">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h1>NUCLEARCMS</h1>
                <p>DEscrição do projecto nuclear</p>
                <p>Projeto do nuclear</p>
            </div>
            <div class="col-sm-3 ">
                <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                  <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
        </div>
    </div>
</div><?php }
}

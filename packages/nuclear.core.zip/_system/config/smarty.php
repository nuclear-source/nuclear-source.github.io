<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['smarty.cache_status'] = FALSE;
$config['smarty.theme_path'] = NUCLEARCONTENT.'/themes/';
$config['smarty.theme_name'] = '';
$config['smarty.cache_lifetime'] = 3600;
$config['smarty.compile_directory'] = NUCLEARPATH."cache/".APPNAME."/compiled/";
$config['smarty.cache_directory'] =  NUCLEARPATH."cache/".APPNAME."/cached/";
$config['smarty.config_directory'] = APPPATH."config/";
$config['smarty.template_ext'] = 'tpl';
$config['smarty.template_error_reporting'] = E_ALL & ~E_NOTICE;
$config['smarty.smarty_debug'] = FALSE;
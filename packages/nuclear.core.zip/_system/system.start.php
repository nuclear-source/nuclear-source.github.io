<?php defined('INDEXPATH') OR exit('No direct script access allowed');

//IF NOT DEFAULT
if(!isset($default) && !isset($defaultsrc))
{
	require_once "system.func.php";
	$return = return_uri();
	if(!isset($return['uri'][0]))
		$defaultsrc=true;
	else
	{
		if(is_dir($path_to_nuclear.$src.'/_'.$return['uri'][0])){
			$public_core  =$path_to_nuclear.$src.'/_'.$return['uri'][0];
			$content_path =$path_to_nuclear.$src.'/_'.$return['uri'][0];
		}
		else
			$defaultsrc=true;
	}
	
	if(isset($defaultsrc))
		define('ISDEFAULT',true);
}
else
	define('ISDEFAULT',true);

if(defined('ISDEFAULT'))
{
	$app_name     =$appDEFAULT;
	if(isset($defaultsrc)){
		$public_core  =$path_to_nuclear.$src.'/'.$appFOLDER;
		$content_path =$path_to_nuclear.$src.'/'.$appFOLDER;	
	}
	else{
		$public_core  =$path_to_nuclear.$appFOLDER;
		$content_path =$path_to_nuclear.$appFOLDER;
	}
}




$framework = 'Codeigniter';
defined('PRIVATENAME') or define('PRIVATENAME', '');


define('APPNAME',      $appDEFAULT);
define('NUCLEARCORE',  $public_core);
define('NUCLEARCONTENT', $content_path);
define('NCPATH', INDEXPATH.'/');
define('VENDORPATH', str_replace($inc,'',__DIR__.'/').'_vendor'.DIRECTORY_SEPARATOR);
require_once "system.autoload.php";
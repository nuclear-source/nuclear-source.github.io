<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:32:26
  from "X:\xampp\htdocs\_dev\projects\_nuclear\_apps\admin\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea16a74ced4_29498213',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f4052d8863d41a5d236a3c3bf573ed8fd7a099f7' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\_apps\\admin\\themes\\default\\common\\footer.tpl',
      1 => 1460680722,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea16a74ced4_29498213 (Smarty_Internal_Template $_smarty_tpl) {
?>

<?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:29:43
  from "X:\xampp\htdocs\_dev\projects\espaco\apps\_nuclear\_apps\admin\themes\default\layouts\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea0c71dda95_20499597',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4dba142b4ab793fb74c730997fca2caf00d3e749' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\espaco\\apps\\_nuclear\\_apps\\admin\\themes\\default\\layouts\\login.tpl',
      1 => 1460680725,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea0c71dda95_20499597 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE HTML>
<html lang="PT">
<?php echo $_smarty_tpl->tpl_vars['head']->value;?>

<body>
<section class="container">
	<div class="row">
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

	</div>
	</section>
	</body>
</html><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:32:26
  from "X:\xampp\htdocs\_dev\projects\_nuclear\_apps\admin\themes\default\common\sidebar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea16a05fbc3_62225849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cb607cc401bf846a06a17b57014a0ca97569e795' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\_apps\\admin\\themes\\default\\common\\sidebar.tpl',
      1 => 1463648049,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea16a05fbc3_62225849 (Smarty_Internal_Template $_smarty_tpl) {
?>
<header>
	<li class="list-group-item active">
     	<button class="btn btn-default btn-lg" onclick="toggleleft();"><i class="fa fa-remove"></i></button>
    	<div><i class="fa fa-bars"></i> Menu</div>
  	</li>
</header>
<section>
	<ul class="list-group">
 		<nav class="sidebar-nav">
			<ul class="metismenu" id="menu">
				<?php if (isset($_smarty_tpl->tpl_vars['sidebar_menu']->value)) {?>
			        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['sidebar_menu']->value->item, 'foo', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
$__foreach_foo_1_saved = $_smarty_tpl->tpl_vars['foo'];
?>
			       <?php if ($_smarty_tpl->tpl_vars['foo']->value->permission == 0) {?>
				    <li class="<?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url) {?>active<?php }
if ($_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>active<?php }?>">
				      	<a href="<?php if (!isset($_smarty_tpl->tpl_vars['foo']->value->childs)) {
echo $_smarty_tpl->tpl_vars['baseurl']->value;
echo $_smarty_tpl->tpl_vars['foo']->value->url;
}?>" >
				      		<span class="<?php echo $_smarty_tpl->tpl_vars['foo']->value->icon;?>
"></span>
				      		<?php echo $_smarty_tpl->tpl_vars['foo']->value->label->{$_smarty_tpl->tpl_vars['langkey']->value};?>
	
						   	
							<?php if (isset($_smarty_tpl->tpl_vars['foo']->value->module) && $_smarty_tpl->tpl_vars['foo']->value->module == 'articles') {?>
								
							   	<span class="glyphicon  arrow"></span></a>
							   	<ul aria-expanded="<?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>true<?php } else { ?>false<?php }?>" class="collapse <?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>in<?php }?>">
							   		<li><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
articles"><i class="fa fa-eye"></i> Ver todos</a></li>
							       	<li><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
articles/create/group"><i class="fa fa-plus"></i> Nova Categoria</a></li>
							   
							   		<?php if (isset($_smarty_tpl->tpl_vars['articlesgroup']->value)) {?>
							   		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['articlesgroup']->value['results'], 'foo2', false, 'fokey2');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey2']->value => $_smarty_tpl->tpl_vars['foo2']->value) {
$_smarty_tpl->tpl_vars['foo2']->_loop = true;
$__foreach_foo2_2_saved = $_smarty_tpl->tpl_vars['foo2'];
?>
							      		<li class="<?php if ($_smarty_tpl->tpl_vars['nmethod']->value == $_smarty_tpl->tpl_vars['foo2']->value->slug) {?>active<?php }?>">
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
articles/group/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
" class="btn btn-primary btn-xs pull-left gear" ><i class="fa fa-gear"></i></a>
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
articles/table/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
"  style="text-transform:uppercase">
							      		<span class="<?php echo $_smarty_tpl->tpl_vars['foo2']->value->groupsICON;?>
"></span> <?php echo $_smarty_tpl->tpl_vars['foo2']->value->title;?>

							      			</a></li>
							       	<?php
$_smarty_tpl->tpl_vars['foo2'] = $__foreach_foo2_2_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
							       	<?php }?>
							       	
							    </ul>
								
							<?php }?>
							<?php if (isset($_smarty_tpl->tpl_vars['foo']->value->module) && $_smarty_tpl->tpl_vars['foo']->value->module == 'catalogo') {?>
									<span class="glyphicon  arrow"></span></a>
							   	<ul aria-expanded="<?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>true<?php } else { ?>false<?php }?>" class="collapse <?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>in<?php }?>">
							   	<li class="<?php if ($_smarty_tpl->tpl_vars['ncontrol']->value == 'create' && $_smarty_tpl->tpl_vars['nmethod']->value == 'group') {?> active<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
catalogo/create/group"><i class="fa fa-plus"></i> Nova Categoria</a></li>
							   		<li class="<?php if ($_smarty_tpl->tpl_vars['ncontrol']->value == 'manage' && $_smarty_tpl->tpl_vars['nmethod']->value == '') {?> active<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
catalogo/manage/"><i class="fa fa-list-ul"></i> Gerir Categorias</a></li>
							   	
								<?php if (isset($_smarty_tpl->tpl_vars['cataloguegroup']->value)) {?>
							   		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cataloguegroup']->value['results'], 'foo2', false, 'fokey2');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey2']->value => $_smarty_tpl->tpl_vars['foo2']->value) {
$_smarty_tpl->tpl_vars['foo2']->_loop = true;
$__foreach_foo2_3_saved = $_smarty_tpl->tpl_vars['foo2'];
?>
							      		<li class="<?php if ($_smarty_tpl->tpl_vars['nmethod']->value == $_smarty_tpl->tpl_vars['foo2']->value->slug) {?>active<?php }?>">
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
catalogo/group/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
" class="btn btn-primary btn-xs pull-left gear" ><i class="fa fa-gear"></i></a>
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
catalogo/table/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
"  style="text-transform:uppercase">
							      		<span class="<?php echo $_smarty_tpl->tpl_vars['foo2']->value->groupsICON;?>
"></span> <?php echo $_smarty_tpl->tpl_vars['foo2']->value->title;?>

							      			</a></li>
							       	<?php
$_smarty_tpl->tpl_vars['foo2'] = $__foreach_foo2_3_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
								<?php }?>
								 </ul>
							<?php }?>
							<?php if (isset($_smarty_tpl->tpl_vars['foo']->value->module) && $_smarty_tpl->tpl_vars['foo']->value->module == 'shop') {?>
								
							   	<span class="glyphicon  arrow"></span></a>
							   	<ul aria-expanded="<?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>true<?php } else { ?>false<?php }?>" class="collapse <?php if (('').($_smarty_tpl->tpl_vars['nameClass']->value) == $_smarty_tpl->tpl_vars['foo']->value->url || $_smarty_tpl->tpl_vars['nameClass']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>in<?php }?>">
							   			   	<li class="<?php if ($_smarty_tpl->tpl_vars['ncontrol']->value == 'create' && $_smarty_tpl->tpl_vars['nmethod']->value == 'group') {?> active<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
shop/create/group"><i class="fa fa-plus"></i> Nova Categoria</a></li>
							   		<li class="<?php if ($_smarty_tpl->tpl_vars['ncontrol']->value == 'manage' && $_smarty_tpl->tpl_vars['nmethod']->value == '') {?> active<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
shop/manage/"><i class="fa fa-list-ul"></i> Gerir Categorias</a></li>  	
				
							   		
							   		<?php if (isset($_smarty_tpl->tpl_vars['storegroup']->value)) {?>
							   		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['storegroup']->value['results'], 'foo2', false, 'fokey2');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey2']->value => $_smarty_tpl->tpl_vars['foo2']->value) {
$_smarty_tpl->tpl_vars['foo2']->_loop = true;
$__foreach_foo2_4_saved = $_smarty_tpl->tpl_vars['foo2'];
?>
							      		<li class="<?php if ($_smarty_tpl->tpl_vars['nmethod']->value == $_smarty_tpl->tpl_vars['foo2']->value->slug) {?>active<?php }?>">
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
shop/group/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
" class="btn btn-primary btn-xs pull-left gear" ><i class="fa fa-gear"></i></a>
							      		 <a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
shop/table/<?php echo $_smarty_tpl->tpl_vars['foo2']->value->slug;?>
"  style="text-transform:uppercase">
							      		<span class="<?php echo $_smarty_tpl->tpl_vars['foo2']->value->groupsICON;?>
"></span> <?php echo $_smarty_tpl->tpl_vars['foo2']->value->title;?>

							      			</a></li>
							       	<?php
$_smarty_tpl->tpl_vars['foo2'] = $__foreach_foo2_4_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
							       	<?php }?>
							     
							    </ul>
								
							<?php }?>
					 	 </a>					   					   		
			   		</li>	
			   		<?php }?>
			     	<?php
$_smarty_tpl->tpl_vars['foo'] = $__foreach_foo_1_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
		      	 <?php }?>	
		      	 <?php if (isset($_smarty_tpl->tpl_vars['restrict']->value)) {?>
			        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['restrict']->value->item, 'foo', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
$__foreach_foo_5_saved = $_smarty_tpl->tpl_vars['foo'];
?>
				    <li>
				      	<a href="<?php if (!isset($_smarty_tpl->tpl_vars['foo']->value->childs)) {
echo $_smarty_tpl->tpl_vars['baseurl']->value;
echo $_smarty_tpl->tpl_vars['foo']->value->url;
}?>" class="<?php if ($_smarty_tpl->tpl_vars['active']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>active<?php }?>">
				      		<span class="<?php echo $_smarty_tpl->tpl_vars['foo']->value->icon;?>
"></span>
				      		<?php echo $_smarty_tpl->tpl_vars['foo']->value->label->{$_smarty_tpl->tpl_vars['langkey']->value};?>
		      	
						   	<?php if (isset($_smarty_tpl->tpl_vars['foo']->value->childs)) {?>
						   	<span class="glyphicon arrow"></span></a>
						   	<ul aria-expanded="<?php if ($_smarty_tpl->tpl_vars['active']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>true<?php } else { ?>false<?php }?>" class="collapse <?php if ($_smarty_tpl->tpl_vars['active']->value == $_smarty_tpl->tpl_vars['foo']->value->url) {?>in<?php }?>">
						   		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['foo']->value->childs->item, 'foo2', false, 'fokey2');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey2']->value => $_smarty_tpl->tpl_vars['foo2']->value) {
$_smarty_tpl->tpl_vars['foo2']->_loop = true;
$__foreach_foo2_6_saved = $_smarty_tpl->tpl_vars['foo2'];
?>
						      		<li class="<?php if ((($_smarty_tpl->tpl_vars['active']->value).('/')).($_smarty_tpl->tpl_vars['nmethod']->value) == $_smarty_tpl->tpl_vars['foo2']->value->url) {?>active<?php }?>"><a href="<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;
echo $_smarty_tpl->tpl_vars['foo2']->value->url;?>
"><span class="<?php echo $_smarty_tpl->tpl_vars['foo2']->value->icon;?>
"></span> <?php echo $_smarty_tpl->tpl_vars['foo2']->value->label->{$_smarty_tpl->tpl_vars['langkey']->value};
echo $_smarty_tpl->tpl_vars['base_url']->value;?>
</a></li>
						       	<?php
$_smarty_tpl->tpl_vars['foo2'] = $__foreach_foo2_6_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
						    </ul>
							<?php }?>
					 	 </a>					   					   		
			   		</li>	
			     	<?php
$_smarty_tpl->tpl_vars['foo'] = $__foreach_foo_5_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
		      	 <?php }?>	
		      	 
           
			</ul>
		</nav>
	</ul>
</section>
<?php }
}

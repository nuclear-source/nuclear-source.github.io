<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:32:25
  from "X:\xampp\htdocs\_dev\projects\_nuclear\_apps\admin\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea1699d6c30_98974111',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6776222a2999a7e6d54f1d585a1a3a3fcddca147' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\_apps\\admin\\themes\\default\\common\\head.tpl',
      1 => 1463647800,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea1699d6c30_98974111 (Smarty_Internal_Template $_smarty_tpl) {
?>
<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/bootnuclear.css"        >	
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/metismenu.min.css"      >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/responsive-layouts.css" >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/uploadfile.css"         >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/datatables.min.css"   >
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/jqueryFileTree.css"     >		
		<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/css/manager.css"><?php }
}

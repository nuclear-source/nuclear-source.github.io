<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:35:07
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-core\_apps\admin\themes\default\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea20b0c2b80_96757762',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b76ad101b7f8ceb36c975cf81d81dc4bc3b0d050' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-core\\_apps\\admin\\themes\\default\\common\\scripts.tpl',
      1 => 1463647818,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea20b0c2b80_96757762 (Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 src="http://code.jquery.com/jquery-1.12.1.min.js"><?php echo '</script'; ?>
> 
<?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/metismenu/metismenu.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/summernote/summernote.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/responsive-layouts.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/datatables.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript"	src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/sortable/jquery-ui.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript"	src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/sortable/jquery.mjs.nestedSortable.js"><?php echo '</script'; ?>
>
<style>
.form-control{
background:#fff
}
</style>
<!-- jQuery File Upload Dependencies -->				
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/uploadfiles/jquery.knob.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/uploadfiles/jquery.ui.widget.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/uploadfiles/jquery.iframe-transport.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/uploadfiles/jquery.fileupload.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
>
var publicpathjs = '<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
';
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
$("#myprix").change(function() {
  var val = $('#myprix').val();
  var num = parseFloat(val).toFixed(2);
  $('#myprix').val(num);
});
<?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/uploadfiles/script.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
admin/js/vendor/filetree/jqueryFileTree.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript">

			$(document).ready( function() {
				$('#fileTreeDemo_1').fileTree({ script: '<?php echo $_smarty_tpl->tpl_vars['baseurl']->value;?>
'}, function(file) { });
			});
		<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
ResponsiveLayouts('btn btn-default','<i class="fa fa-bars"></i>','<i class="fa fa-bars"></i>');
<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
// For demo to fit into DataTables site builder...
$(document).ready(function() {
				$('#example').DataTable( {
			        "order": [[ 0, "asc" ]]
			    } );
			} );

$('#example')
	.removeClass( 'display' )
	.addClass('table table-striped table-bordered');

function sort(s)
{
if(s==1)
{
	$('.orders').show();
	$('#on_sort').hide();
	$('#sortable').sortable("enable");
	$('#off_sort').show();
}
else{
	$('.orders').hide();
	$('#off_sort').hide();
	$('#sortable').sortable("disable");
	$('#on_sort').show();
}

}
$( document ).ready(function() {
	 $('#menu').metisMenu();
	 $( "#sortable" ).sortable({
		
	     placeholder: "alert alert-warning ",
	     cursor: 'move',
	     handle: '.handle',
	     update: function(event, ui) {
	         var order = $("#sortable").sortable("toArray");


	         $.ajax({
	       	   url: this.href,
	       	   data: {
	       	      menus:  order.join(",")
	       	   },
	       	   error: function() {
	       	      $('#info').html('<p>An error has occurred</p>');
	       	   },
	       	   success: function(data) {
	       	   },error: function(erro) {
	            	  alert('ocurreu um erro');
	              },
	       	   type: 'POST'
	       	});

	         
	     }
	 });
	$('#sortable').sortable("enable");
	 $('.orders').hide();
});


<?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>

<?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript">
$(document).ready(function() {
	
    	$('.summernote').summernote({
    		fontNames: [
    		            'Roboto', 'Sans', 'Arial', 'Arial Black'
    		        ],
    		        fontNamesIgnoreCheck: [
    		                               'Roboto'
    		                           ],
    		  toolbar: [
    		    ['style', ['bold', 'italic', 'underline', 'clear']],
    		    ['font', ['strikethrough', 'superscript', 'subscript']],
    		    ['fontsize', ['fontsize','fontname']],
    		    ['height', ['height']],
    		    ['color', ['color']],
    		    ['para', ['ul', 'ol', 'paragraph']],
    		    ['code', ['codeview']]
    		  ],
    		  height:'350px'
    		});
    	$('.summernote2').summernote({
    		fontNames: [
    		            'Roboto', 'Sans', 'Arial', 'Arial Black'
    		        ],
    		        fontNamesIgnoreCheck: [
    		                               'Roboto'
    		                           ],
    		  toolbar: [
    		    ['style', ['bold', 'italic', 'underline', 'clear']],
    		    ['font', ['strikethrough', 'superscript', 'subscript']],
    		    ['fontsize', ['fontsize','fontname']],
    		    ['height', ['height']],
    		    ['color', ['color']],
    		    ['para', ['ul', 'ol', 'paragraph']],
    		    ['code', ['codeview']]
    		  ],
    		  height:'350px'
    		});
    	$('.summernote3').summernote({
    		fontNames: [
    		            'Roboto', 'Sans', 'Arial', 'Arial Black'
    		        ],
    		        fontNamesIgnoreCheck: [
    		                               'Roboto'
    		                           ],
    		  toolbar: [
    		    ['style', ['bold', 'italic', 'underline', 'clear']],
    		    ['font', ['strikethrough', 'superscript', 'subscript']],
    		    ['fontsize', ['fontsize','fontname']],
    		    ['height', ['height']],
    		    ['color', ['color']],
    		    ['para', ['ul', 'ol', 'paragraph']],
    		    ['code', ['codeview']]
    		  ],
    		  height:'350px'
    		});
    });
    <?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
>
function delete_item()
{
	if (confirm('Tem a certeza que deseja remover este registo?')) {
		this.form.submit();
	} else {
		event.preventDefault();	 return false;
	}
}

<?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
>
var target='';
function 
	selecionaimage(obj){
		var image = $(obj).attr('src');
		var urlimage=image.replace('<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
uploads/crop/sm/', "");
		var targetimg2 = $(target).find('.thumbnail');
		$(targetimg2).css('background-image','url(' + image + ')');		
		var targetimg = $(target).find('img');
		$(targetimg).attr('src',image);
		var input = $(target).find('input');
		$(input).val(urlimage);
		$('#myModal').modal('toggle')		
	}
function 
	getimage(obj){
		target=$(obj).parent();
	}
function 
	new_img(){
		event.preventDefault();
		var ht = $('#newimg').html();
		$('#newimgs').append(ht);
	}
function 
	remova(este){	
		event.preventDefault();
		$(este).parent().parent().remove();
	}
<?php echo '</script'; ?>
>
	
<?php echo '<script'; ?>
>

/*
$(function() {				
    Morris.Area({
        element: "morris-area-chart",			        
        data: <?php echo $_smarty_tpl->tpl_vars['morris']->value;?>
,
        xkey: "period",
        ykeys: ["totalusers","totalindex","total"],
        labels: ["Utilizadores","Visitas","PageViews"],
        pointSize: 3,
        hideHover: "auto",
        xLabels:"day"
    });	  
});
*/
<?php echo '</script'; ?>
>
			
            
           <?php }
}

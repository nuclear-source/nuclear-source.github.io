<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 09:37:49
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ebecda3eda1_49626986',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b18f3f81fe9ac1241661bffbbf9c141623f0e945' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\common\\head.tpl',
      1 => 1463729856,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ebecda3eda1_49626986 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title><?php echo strtoupper($_smarty_tpl->tpl_vars['content']->value->title);
echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 - <?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
 </title>
     <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->subtitle;?>
 <?php echo $_smarty_tpl->tpl_vars['project']->value['description'];?>
">
     <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->keywords;?>
">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" href="data:image/x-icon;base64,<?php echo $_smarty_tpl->tpl_vars['favicon']->value;?>
" type="image/x-icon" />
   	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> 
   

   
         <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-24 15:51:25
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\_nuclear\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57445c5d46f139_57466976',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '05305f2b6a196de30a3342a1883fb483d5ec236c' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\_nuclear\\themes\\default\\common\\footer.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57445c5d46f139_57466976 (Smarty_Internal_Template $_smarty_tpl) {
}
}

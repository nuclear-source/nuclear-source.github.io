<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:29:31
  from "X:\xampp\htdocs\_dev\projects\espaco\apps\_nuclear\_nuclear\themes\default\common\navbar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea0bb86ed51_06419000',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7218dfd5ea62c4febe56812fd1c51743823967de' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\espaco\\apps\\_nuclear\\_nuclear\\themes\\default\\common\\navbar.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ea0bb86ed51_06419000 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top " data-spy="affix" data-offset-top="100" style="z-index:1000">
        <div class="container" >
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
          		<a class="navbar-brand " href="<?php echo base_url();?>
" style="color:#fff"><b>DEFAULT</b>application</a>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
             <ul class="nav navbar-nav navbar-right">     
               <li><a href="<?php echo base_url();?>
"><i class="glyphicon glyphicon-refresh"></i> Refresh</a></li>
             </ul>
            </div>
        </div>
    </nav>
<?php }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require VENDORPATH."MX/Controller.php";
class NUCLEAR_Controller extends MX_Controller  
{	
	public static $instance;
	public $themename = '';
	public  $data=array();
	public $theme_folder='';/// FROM OLD_VERSION
	
	function __construct() {
		parent::__construct();
		self::$instance = $this;
		$this->__init();
		
	}
	
	static public function get_instance(){
		$ci = self::$instance;
		return $ci;
	}
	
	public function _get($model,$where=array(),$order=array(),$limit='')
	{	
		$dao = $model.'_dao';
		$this->load->model($dao);
		$data = $this->$dao;
		$data->class=$where;
		$data->itens=$this->$dao->get($where,$order,$limit);
		return $data;
		
	}
	
	
	
	public function render($url,$data=array(),$true=false)
	{
		$this->load->library('parse');
		$this->parse->parse($url,$data,$true);
	}
 
	public function template($url,$data=array(),$true=false)
	{
	  	$this->parser->parse($this->themename.'/'.$url,$data,true);
	}
  
	
	
	public function _multitypes()
	{
		$type=array();
		$type[0]='categorie';
		$type[1]='article';
		$type[2]='page';
		$type[3]='feature';
		return $type;
	}
    private function __init()
    {
    	
    	$this->theme_folder =  $this->config->item('FolderTemplate');
    	$this->load->library('parser');
    	$this->load->config('smarty');
    	$this->themename=$this->config->item('smarty.theme_name');
    	$this->load->helper(array('url','cookie'));
    /*
        if(VERSION=='demo' && $this->input->cookie('app_version')=='' && $this->uri->uri_string()!='/demo/login')
        {	
        	header('Location: '.base_url().'demo/login/');
        	exit();
        }
    	 */
    	if(defined('PRIVATENAME')){$prive = PRIVATENAME.'/';}else{$prive='';}
    	define('PUBLICPATH', base_url());
    	define('MODULECALL', NUCLEARCORE);
    	//////////////////////////////////////////////DEFAULT
    	$this->data['root']        = $this->config->item('root_base');
    	$this->data['storage']     = $this->config->item('storage_folder').'/';
    	$this->data['assets']      = base_url().$this->config->item('static_assets').'/';
    	$this->data['static']      = base_url().$prive.$this->config->item('static_theme').'/'; 
    	$this->data['languages']   = $this->config->item('language');
    	$this->data['langkey']     = $this->config->item('language_abbr');
    	$this->data['langs']       = $this->config->item('lang_uri_abbr');  
    	$this->data['nameClass']   = $this->router->fetch_class();
    	$this->data['uri']         = $this->uri->uri_string();
		/////////////////////////////////////////////////////////////////COMMON PARAMS
		
    	$this->data['ncontrol']    = $this->uri->segment(0);
    	$this->data['nmethod']     = $this->uri->segment(1);
    	$this->data['naction']     = $this->uri->segment(2);
    	$this->data['naction2']    = $this->uri->segment(3);
    	$this->data['baseurl']     = base_url().$prive;
    	////////////////////////////////////////////////////////////////////CUSTOMIZE PAGE    	
    	$newuri = $this->_urirearange();    	
    	$this->data['uri_folders_array']=$newuri;
    	$this->data['uri_folders']=implode('/',$newuri).'/';
    	$this->data['active']=$this->_getactive();
    	$this->data['breadcrumb']=array('Home'=>'');    	
    	$this->data['this_base']         = base_url();
    	if($this->data['uri_folders']!='/')
    	{
    		$this->data['this_base'].=$this->data['uri_folders'];
    		foreach($newuri as $ki=>$val)
    		{
    			if($val.'/' !=$prive)
    			{
    				$this->data['breadcrumb'][$val]=base_url().$val;
    			}
    			
    		}
    		
    		
    	}
    	
    	$this->data['this_base'].=$this->data['nameClass'].'/';
    	$this->data['breadcrumb'][$this->data['nameClass']]=$this->data['this_base'];
    	
    	if($this->data['ncontrol']!='' && $this->data['ncontrol']!=$this->data['nameClass']){
    		$this->data['breadcrumb'][$this->data['ncontrol']]=$this->data['this_base'].$this->data['ncontrol'];
    	}
    	if($this->data['nmethod']!=''){
    		$this->data['breadcrumb'][$this->data['nmethod']]=$this->data['this_base'].$this->data['ncontrol'].'/'.$this->data['nmethod'];
    	}
    	///OLD FUNCTION
    	foreach($this->data as $key=>$value)
    	{
    		if($key!='uri'){

    			$this->$key=$value;
    		}
    	}
    }

    public function _prepare()
    {
    	//////////////////////////////////////////////COMMON INIT
    	
    	$this->load->model('config_model');
    	$this->load->model('database/menus_model');
    	$this->data['data']=$this->data;
    	$this->data['project']    = $this->config_model->get_configs();
    	$this->data['navigation'] = $this->menus_model->get_table(0);
    	$this->load->helper('file');
    	$this->config->load('smarty');
    	$this->load->library(array('parser','parse'));
    	/////////////////////////////////////////////////////////////
    }
    
    public function _print()
    {
    		
    	    $this->load->library(array('parser','parse'));
			$this->parse->parse("index.tpl", $this->data);
    }
    
    public function _getactive()
    {
		if(count($this->data['uri_folders'])==1 && $this->data['uri_folders']=='/')
    	{
    		$active=$this->data['nameClass'];    	
    	}else
    	{
    		$active=$this->data['uri_folders'].$this->data['nameClass'];
    	}
    	return $active;
    }
    
    public function _urirearange()
    {
    	$uris = explode('/',$this->uri->uri_string());
    	$uris=array_filter($uris);$a=0;
    	foreach ($uris as $key=>$val){
    		if($this->data['nameClass']==$val)
    			$a=1;
    		if($a==1)
    			unset($uris[$key]);
    		if($this->data['ncontrol']==$val)
    			$a=-1;
    		if($a==-1)
    			unset($uris[$key]);
    	}
    	$n=0;$new_uris=array();
    	foreach ($uris as $key=>$val){
    		$new_uris[$n]=$val;
    		$n+=1;}
    	return $new_uris;
    }
    
    public function _render($layout)
    {
    	$this->load->library(array('parser','parse'));
    	  	    	
    	foreach($layout as $key=>$val)
    	{
    		$this->data[$val]=true;
    	}
    	
    		
    	
    	if(isset($this->partial)){
    		$this->data['partial']=$this->partial;
    	}
    	$this->parse->parse("layouts/index.tpl", $this->data);
    	
    }
    public function _render2($layout,$template)
    {
    	$this->load->library(array('parser','parse'));
    	 
    	foreach($layout as $key=>$val)
    	{
    		$this->data[$val]=true;
    	}
    	 
      $this->data['template']=$template;
    	 
    	if(isset($this->partial)){
    		$this->data['partial']=$this->partial;
    	}
    	$this->parse->parse("layouts/index.tpl", $this->data);
    	 
    }
    public function _type($typename='')
    {
    	$type=array('pages'=>0,'categories'=>1,'articles'=>2,'features'=>3,'sections'=>'33','sections_objects'=>'34');
    	if(isset($type[$typename]))
    	{
    		return $type[$typename];
    	}
    	
    }
    
 
    
    
    //////////OLD FUNCTIONS

	public function _render_page($view, $data=null, $returnhtml=false)
	{	//I think this makes more sense
		$this->viewdata = (empty($data)) ? $this->data: $data;
		$view_html  = $this->load->view($this->theme_folder.'common/head.php', $this->viewdata, $returnhtml);
		if($view!='login'){
			$view_html = $this->load->view($this->theme_folder.'common/navbar.php', $this->viewdata, $returnhtml);
		}
		$view_html = $this->load->view($this->theme_folder.'common/body.php', $this->viewdata, $returnhtml);
		$view_html = $this->load->view($this->theme_folder.$view, $this->viewdata, $returnhtml);
		$view_html = $this->load->view($this->theme_folder.'common/footer.php', $this->viewdata, $returnhtml);
		$view_html = $this->load->view($this->theme_folder.'common/scripts.php', $this->viewdata, $returnhtml);
		if ($returnhtml) return $view_html;
	}
    
   
}
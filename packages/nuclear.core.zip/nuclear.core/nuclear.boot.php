<?php defined('INDEXPATH') OR exit('No direct script access allowed');

/*****************
 * BOOT FRAMEWORK
 * *************/
$bootstrap   = parse_ini_file(".conf", true);
if(isset($bootstrap['system']['config']) && is_file(__DIR__.'/'.$bootstrap['system']['config']))	
	$bootstrap = parse_ini_file(__DIR__.'/'.$bootstrap['system']['config'], true);
/*****************
 * DEFINE CORE
 * ***************/
if(!isset($bootstrap['app']) || !isset($bootstrap['system'])){
	echo 'NuclearCMS - Boot::ERROR (line13)';die();}
$app    = $bootstrap['app']; 
$system = $bootstrap['system'];
/*****************
 * BOOT DEBUG
 * *************/
if(!isset($app['default']) || 
   !isset($app['folder' ]) || 
   !isset($app['version']) ||
   !isset($app['assets' ]) ){
	echo 'NuclearCMS - Boot::ERROR (line18)';die();}
if(!isset($system['path'])){
	echo 'NuclearCMS - System::PATH (line20)';die();}
/*****************
 * CONFIG APPLICATION
 * *************/
$appDEFAULT  = $app['default']; 
$appFOLDER   = $app['folder'];  
$appVERSION  = $app['version'];
$appASSETS   = $app['assets'];
$inc         = $system['path'].'/';
$src         = $system['src'];
/*****************
 * RUN FRAMEWORK
 * *************/
if(isset($system['force'])) //force or ignore module:error
	$force = true;
if(isset($src)) //test modules
	require_once 'nuclear.run.php';
else 
	$default=true;  //define as default nuclear
/*****************
 * START SYSTEM
 * *************/
require_once $inc.'system.start.php';



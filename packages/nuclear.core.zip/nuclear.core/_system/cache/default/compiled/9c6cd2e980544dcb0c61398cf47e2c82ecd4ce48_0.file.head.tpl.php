<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 08:42:32
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_nuclear\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573eb1d81c4304_65941361',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9c6cd2e980544dcb0c61398cf47e2c82ecd4ce48' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_nuclear\\themes\\default\\common\\head.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573eb1d81c4304_65941361 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title><?php echo strtoupper($_smarty_tpl->tpl_vars['content']->value->title);
echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 - <?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
 </title>
     <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->subtitle;?>
 <?php echo $_smarty_tpl->tpl_vars['project']->value['description'];?>
">
     <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->keywords;?>
">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="icon" href="data:image/x-icon;base64,<?php echo $_smarty_tpl->tpl_vars['favicon']->value;?>
" type="image/x-icon" />
   	 <link rel="stylesheet" href="https://uxcdn.firebaseapp.com/css/nuclear.css"> 
   	 <style><?php echo $_smarty_tpl->tpl_vars['styles']->value;?>
.zoom:after { background:url(<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/uploads/icon.png);}#ex1 img:hover { cursor: url(<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/uploads/grab.cur), default;}</style>
   <?php echo '<script'; ?>
 src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"><?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="https://uxcdn.firebaseapp.com/jquery-1.11.2.min"><\/script>')<?php echo '</script'; ?>
>
   <?php echo '<script'; ?>
>window.jQuery || document.write('<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/static/js/jquery-1.11.2.min.js"><\/script>')<?php echo '</script'; ?>
>

   
         <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 08:42:32
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_nuclear\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573eb1d85e1b78_78431000',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b28c93613540f05418558c4a6a63cc3b9fc87b54' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_nuclear\\themes\\default\\common\\footer.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573eb1d85e1b78_78431000 (Smarty_Internal_Template $_smarty_tpl) {
}
}

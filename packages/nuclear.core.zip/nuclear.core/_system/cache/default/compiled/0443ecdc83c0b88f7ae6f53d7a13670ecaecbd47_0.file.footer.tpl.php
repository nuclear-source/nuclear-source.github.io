<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-24 15:57:29
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\default\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57445dc9639d18_96496188',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0443ecdc83c0b88f7ae6f53d7a13670ecaecbd47' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\default\\themes\\default\\common\\footer.tpl',
      1 => 1461660734,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57445dc9639d18_96496188 (Smarty_Internal_Template $_smarty_tpl) {
}
}

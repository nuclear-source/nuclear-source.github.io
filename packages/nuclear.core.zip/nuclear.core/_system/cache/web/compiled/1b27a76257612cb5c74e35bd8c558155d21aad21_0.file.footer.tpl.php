<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-23 20:50:59
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-custom\_apps\web\themes\default\common\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_574351136fc3c3_41962054',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1b27a76257612cb5c74e35bd8c558155d21aad21' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-custom\\_apps\\web\\themes\\default\\common\\footer.tpl',
      1 => 1463733811,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_574351136fc3c3_41962054 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="container-fluid well">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h1>NUCLEARCMS</h1>
                <p>DEscrição do projecto nuclear</p>
                <p>Projeto do nuclear</p>
            </div>
            <div class="col-sm-3 ">
                <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                  <h3 class="page-header">List</h3>
                <ul class="nav nav-pills nav-stacked ">
                   <li><a href="" >test</a></li>
                    <li><a href="" >test</a></li>
                     <li><a href="" >test</a></li>
                </ul>
            </div>
        </div>
    </div>
</div><?php }
}

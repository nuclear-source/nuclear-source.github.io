<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 08:43:55
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\partials\default.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573eb22b518a32_54387277',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2a061e0840c7c9a5858fc73c0bc96f99e4215214' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\partials\\default.tpl',
      1 => 1463723472,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573eb22b518a32_54387277 (Smarty_Internal_Template $_smarty_tpl) {
?>

<section style="margin-top:120px" >
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
				  <div class="panel-heading">Welcome to default application</div>
				  <div class="panel-body">
				  
				  <div class="col-sm-6">
				  <h4>APPLICATIONS:</h4><br/>
				    <?php if (count($_smarty_tpl->tpl_vars['apps']->value) > 0) {?>
					
				    <b>Select && define DEFAULT_APP</b><br/>
				    	
					   <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['apps']->value, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_0_saved = $_smarty_tpl->tpl_vars['val'];
?>
					  <a href="<?php echo base_url();
echo $_smarty_tpl->tpl_vars['val']->value->uri;?>
"><b><?php echo $_smarty_tpl->tpl_vars['val']->value->name;?>
</b></a>					   <br/>
					   <?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
					  <?php } else { ?> 
					   You dont have any application<br/>create  _apps folder && config.xml file
				     <?php }?>
				    </div>
				  <div class="col-sm-6">				  			 
<?php if (count($_smarty_tpl->tpl_vars['apps']->value) == 0) {?> You dont have any application<br/>to create edit file _apps/config.xml
				  <?php } else { ?>
				  You have <?php echo count($_smarty_tpl->tpl_vars['apps']->value);?>
 applications<br/>to make changes edit file _apps/config.xml
				  <?php }?>
				  </div>				
				<pre>&lt!--Default Application config-code-->
&ltapps>	
	&ltapp>
          &lturi>appname&lt/uri> 
          &ltname>appname&lt/name> 
          &lticon>fa fa-home&lt/icon>
          &ltpermission>0&lt/permission>   /* USE: 0-public, 1-private*/
	&lt/app>
&ltapps>   
		 </pre>
				  </div>
				    
		<div style="clear:both"></div>
		
				</div>
		</div>
		
	</div>
</section><?php }
}

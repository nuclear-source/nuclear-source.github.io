<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 09:38:50
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-web\_apps\web\themes\default\partials\blank.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ebf0a665b11_14717672',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b25187684403c27a8aa89f5a4a6b0e965d7dbffe' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-web\\_apps\\web\\themes\\default\\partials\\blank.tpl',
      1 => 1463729919,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_573ebf0a665b11_14717672 (Smarty_Internal_Template $_smarty_tpl) {
}
}

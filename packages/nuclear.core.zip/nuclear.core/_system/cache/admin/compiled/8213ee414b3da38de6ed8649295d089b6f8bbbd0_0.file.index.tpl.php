<?php
/* Smarty version 3.1.30-dev/51, created on 2016-05-20 07:35:05
  from "X:\xampp\htdocs\_dev\projects\_nuclear\nuclear-core\_apps\admin\themes\default\layouts\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_573ea209e38b80_89525482',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8213ee414b3da38de6ed8649295d089b6f8bbbd0' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev\\projects\\_nuclear\\nuclear-core\\_apps\\admin\\themes\\default\\layouts\\index.tpl',
      1 => 1460680724,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:common/head.tpl' => 1,
    'file:common/navbar.tpl' => 1,
    'file:common/sidebar.tpl' => 1,
    'file:common/no_content.tpl' => 1,
    'file:common/footer.tpl' => 1,
    'file:common/scripts.tpl' => 1,
  ),
),false)) {
function content_573ea209e38b80_89525482 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE HTML>
<html lang="PT">
	<head>
	<?php if (isset($_smarty_tpl->tpl_vars['head']->value)) {?>
		<?php $_smarty_tpl->_subTemplateRender("file:common/head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php }?>	
</head>	
	<body>
	<div class="overlay"></div>
	<?php if (isset($_smarty_tpl->tpl_vars['navbar']->value)) {?>
	<header class="topnav">
		<?php $_smarty_tpl->_subTemplateRender("file:common/navbar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

		</header>	
	<?php }?>
	
	<?php if (isset($_smarty_tpl->tpl_vars['sidebar']->value)) {?>
		<aside class="left"><?php $_smarty_tpl->_subTemplateRender("file:common/sidebar.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</aside>
		<section class="contents hideright">
	<?php } else { ?><section class="contents hideright hideleft"><?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['breadcrumb']->value)) {?>
		<header style="background:rgba(0,0,0,0.5);">
			<ol class="breadcrumb" style="margin-left: 50px;background:rgba(0,0,0,0);line-height:35px;" >
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['breadcrumb']->value, 'foo', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
$__foreach_foo_0_saved = $_smarty_tpl->tpl_vars['foo'];
?>
					<li><a href="<?php echo $_smarty_tpl->tpl_vars['foo']->value;?>
" style="color:#fff"><?php echo $_smarty_tpl->tpl_vars['fokey']->value;?>
</a></li>
				<?php
$_smarty_tpl->tpl_vars['foo'] = $__foreach_foo_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>
			</ol>
		</header>
	<?php }?>
		<article class="container-fluid" id="conteudo">
			<?php if (isset($_smarty_tpl->tpl_vars['partial']->value)) {
$_smarty_tpl->_subTemplateRender(($_smarty_tpl->tpl_vars['partial']->value).('.tpl'), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

			<?php } else {
$_smarty_tpl->_subTemplateRender("file:common/no_content.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
		</article>
	</section>
	<?php if (isset($_smarty_tpl->tpl_vars['footer']->value)) {?>		
		<?php $_smarty_tpl->_subTemplateRender("file:common/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php }?>		
	<?php if (isset($_smarty_tpl->tpl_vars['scripts']->value)) {?>
		<?php $_smarty_tpl->_subTemplateRender("file:common/scripts.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	<?php }?>
	<?php if (isset($_smarty_tpl->tpl_vars['debug']->value)) {?>
		<?php echo $_smarty_tpl->tpl_vars['debug']->value;?>

	<?php }?>	
	</body>
</html>

 <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:40:51
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671f73b7b384_98718805',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c17fe1cdd950d98b6cd06c161541f84932ab03ef' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\common\\head.tpl',
      1 => 1466376037,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671f73b7b384_98718805 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <meta charset="utf-8">

   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

     <title><?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 </title>

     <meta name="description" content="">

     <meta name="viewport" content="width=device-width, initial-scale=1">

     

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/bootnuclear.css"> 

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/default.css">

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/themes/blue.css">

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.css" media="screen">

   <!-- Scripts -->

   <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"><?php echo '</script'; ?>
>

   <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/jquery-1.11.2.min.js"><?php echo '</script'; ?>
><?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:33:09
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\eletro\partials\contactos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671da5cc62a6_12083479',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a2d0ba768f0823a22951b9b9d28163498db00a93' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\eletro\\partials\\contactos.tpl',
      1 => 1465963542,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671da5cc62a6_12083479 (Smarty_Internal_Template $_smarty_tpl) {
?>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24216.265209038018!2d-7.9703887909944395!3d40.6511996276508!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd23378433ff2dab%3A0xa00ebc04f807060!2sTondelinha%2C+3510-633+Viseu!5e0!3m2!1spt-PT!2spt!4v1460766682300"  

width="100%" height="400" style="margin-top:-50px;border:0" frameborder="0"  allowfullscreen></iframe>



<section style="background:#fff;color:#000">

	<div class="container">

		<div class="row"><br/>

		<div class="col-sm-1">

		</div>

		<div class="col-sm-5">

		<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


		</div>

		<div class="col-sm-5 bg1 color0" style="text-transform:uppercase">
<form action="<?php echo base_url();?>
send/mensage" method="post">
		  <div class="row">

		  <div class="col-sm-12 color0"><h2>Envie-nos uma mensagem</h2></div>

	      <div class="col-sm-4  text-right" ><b>nome*:</b></div>

	      	<div class="col-sm-8"><input type="text" name="name" class="form-control"/></div>

      </div>
  <br/>
       <div class="row">

	      <div class="col-sm-4  text-right"><b>localidade:</b></div>

	      	<div class="col-sm-8"><input type="text"  name="local"  class="form-control"/></div>

	    </div>    
      
<br/>
       <div class="row">

	      <div class="col-sm-4  text-right"><b>morada:</b></div>

	      	<div class="col-sm-8"><input type="text"  name="morada"  class="form-control"/></div>

	    </div>
<br/>
       <div class="row">

	      <div class="col-sm-4  text-right"><b>telefone:</b></div>

      	<div class="col-sm-8"><input type="text"  name="telefone"  class="form-control"/></div>

       </div>
<br/>
       <div class="row">

      <div class="col-sm-4  text-right"><b>email*:</b></div>

      	<div class="col-sm-8"><input type="text" name="email"  class="form-control"/></div>

      	 </div>
<br/>
       <div class="row">

      <div class="col-sm-4  text-right"><b>mensagem*:</b></div>

      	<div class="col-sm-8"><textarea  class="form-control"  name="mensage" ></textarea></div>

      	 </div>

      	  <div class="row">
      	  	<div style="clear:both"></div> <br/>

      <div class="col-sm-4"><p style="font-size:10px">* campos obrigatórios</p></div>

      	<div class="col-sm-8">

      	<input type="submit" class="btn btn-default btn-sm" style="padding:6px 12px" value="Enviar "></input>

      	</div>

      	 </div>

      	 <div style="clear:both"></div>  <br/>
</form>
		</div>

		</div>

	</div>

</section>

<section style="clear:both"><br/></section><?php }
}

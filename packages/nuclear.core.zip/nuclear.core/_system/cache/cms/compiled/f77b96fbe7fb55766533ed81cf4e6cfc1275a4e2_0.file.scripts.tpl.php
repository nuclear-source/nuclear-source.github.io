<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:32:00
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\eletro\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671d60f23378_48999703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f77b96fbe7fb55766533ed81cf4e6cfc1275a4e2' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\eletro\\common\\scripts.tpl',
      1 => 1466375519,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671d60f23378_48999703 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Bootstrap Core JavaScript -->
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/nuclear.bootstrap.js"><?php echo '</script'; ?>
>  
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/theme.js"><?php echo '</script'; ?>
>  
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/paralax/parallax.js"><?php echo '</script'; ?>
>
	
			<style>
			.list .item{
					background:#fff;margin:2px 10px;line-height:25px}
			.list .item span{
					color:#000;margin-left:10px;font-size:11px;}
			.list .item a{
					color:#fff;margin-left:10px;text-decoration:none;font-size:14px;float:right;margin:2px}
	
.btn {
border:none;
}
.btn:hover, .btn:focus,.btn:active {
border:none;
}
</style>
			
		
	<?php echo '<script'; ?>
>
	$(".fancybox").fancybox();

	<?php echo '</script'; ?>
>	   <?php }
}

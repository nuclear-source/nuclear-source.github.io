<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 01:12:47
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms-nodb\themes\default\common\scripts.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576726ef2cc5e3_72405428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72b8ca459057ca787ed3e27c87b3acb5034877c6' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms-nodb\\themes\\default\\common\\scripts.tpl',
      1 => 1466376049,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576726ef2cc5e3_72405428 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Bootstrap Core JavaScript -->

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/nuclear.bootstrap.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/cookieconsent.js"><?php echo '</script'; ?>
>    

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/theme.js"><?php echo '</script'; ?>
>  

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/paralax/parallax.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
>

	$(".fancybox").fancybox();

	window.cookieconsent_options = { learnMore: 'Ler Mais', link: 'http://example.com/cookiepolicy' };

	<?php echo '</script'; ?>
>	   <?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:30:49
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\eletro\partials\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671d197fb4e2_87276912',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e3e6aae6c51ae16ef713dbb931ade8a6107b51ec' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\eletro\\partials\\home.tpl',
      1 => 1466375447,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671d197fb4e2_87276912 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="container-fluid" style="margin:0px;padding:0px;">

	<div class="parallax-window  wow fadeIn"  data-wow-duration="1.3s"  data-wow-delay="0.2s"   data-position-y="center" data-parallax="scroll" 
	data-image-src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
lg/<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesIMG;?>
">

		<div class="container" style="padding-top:120px;COLOR:#fff;font-size:24px">		<div class="row">

			<div class="col-sm-12" style="text-align:center;color:#fff;font-weight:100">

				<br/><br/>

				<img src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
contactos.png" height="160px" style="background:#fff" class="wow fadeInUp "  data-wow-duration="0.7s"  data-wow-delay="0.3s" />

				<br/><br/>

				<a class="btn btn-default wow fadeInUp bgtitle"  data-wow-duration="0.9s"  data-wow-delay="0.6s"   href="<?php echo base_url();?>
page/contactos/">Contactar agora</a>

				<div style="clear:both"><br/></div>

			</div>

		</div>

	</div>

</section>





<section style="background:#ccc;">

	<div class="container">

		<div class="row"><br/><br/><br/>

		<?php $_smarty_tpl->_assignInScope('wigets', get_wigets());
?>
	                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['wigets']->value, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_0_saved = $_smarty_tpl->tpl_vars['val'];
?>
	                 	<div class="col-sm-4 "  >
	                 		<p style="text-align:center"><img src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;
echo $_smarty_tpl->tpl_vars['val']->value->wigetIMG;?>
" height="100px"	></p>
					<p style="text-transform:uppercase;font-size:32px;text-align:center;font-weight:bold;"><?php echo $_smarty_tpl->tpl_vars['val']->value->wigetTITLE;?>
</p>
					<p style="text-transform:uppercase;font-size:20px;text-align:center;font-weight:300;"><?php echo $_smarty_tpl->tpl_vars['val']->value->wigetSUBTITLE;?>
</p>
					<p style="text-align:center"><a href="<?php echo $_smarty_tpl->tpl_vars['val']->value->wigetLINK;?>
" class="btn btn-default   bgtitle">+ Saber Mais</a></p>
				</div>
	                 <?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


		</div><div style="clear:both"><br/><br/><br/></div>

	</div>

</section>

<?php }
}

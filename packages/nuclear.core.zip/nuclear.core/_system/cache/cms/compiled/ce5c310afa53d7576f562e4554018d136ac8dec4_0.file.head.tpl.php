<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:46:49
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\pereira\common\head.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576720d9a031e0_59002048',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ce5c310afa53d7576f562e4554018d136ac8dec4' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\pereira\\common\\head.tpl',
      1 => 1466376407,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576720d9a031e0_59002048 (Smarty_Internal_Template $_smarty_tpl) {
?>
   <meta charset="utf-8">

   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

     <title><?php echo strtoupper($_smarty_tpl->tpl_vars['content']->value->title);
echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 - <?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
 </title>

     <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->subtitle;?>
 <?php echo $_smarty_tpl->tpl_vars['project']->value['description'];?>
">

     <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['content']->value->keywords;?>
">

     <meta name="viewport" content="width=device-width, initial-scale=1">

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/bootnuclear.css"> 

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/default.css">

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
css/themes/orange.css">

   <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
libs/fancybox/fancybox.css" media="screen">

   <!-- Scripts -->

   <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"><?php echo '</script'; ?>
>

   <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
js/vendor/jquery-1.11.2.min.js"><?php echo '</script'; ?>
>

   

<?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:15:30
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\teste_smarty.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_5767198234cc28_05474956',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11b2643de8fdf58e04254b6ce89f17cb1e70d831' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\teste_smarty.tpl',
      1 => 1466373996,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5767198234cc28_05474956 (Smarty_Internal_Template $_smarty_tpl) {
?>
teste_:smarty<?php }
}

<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:41:45
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\components\navbar.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671fa9c2e684_32696278',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1cda9967a93310924038fe1acc68c8ed6de0e0dd' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\components\\navbar.tpl',
      1 => 1466376098,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671fa9c2e684_32696278 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!-- Navigation -->

    <nav class="navbar navbar-default navbar-fixed-top affix-top" data-spy="affix" data-offset-top="100" role="navigation" style="z-index:1000">

        <div class="container">

            <!-- Brand and toggle get grouped for better mobile display -->

            <div class="navbar-header page-scroll">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

          		<a class="navbar-brand" href="<?php echo base_url();?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
sm/<?php echo $_smarty_tpl->tpl_vars['project']->value['logotipo'];?>
" ></a>

          </div>

          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

             <ul class="nav navbar-nav navbar-right">     

                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['navigation']->value, 'foo', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['foo']->value) {
$_smarty_tpl->tpl_vars['foo']->_loop = true;
$__foreach_foo_0_saved = $_smarty_tpl->tpl_vars['foo'];
?>

                   <li class="<?php if (($_smarty_tpl->tpl_vars['active']->value).($_smarty_tpl->tpl_vars['ncontrol']->value) == $_smarty_tpl->tpl_vars['foo']->value->menuLINK || ($_smarty_tpl->tpl_vars['active']->value).('/') == $_smarty_tpl->tpl_vars['foo']->value->menuLINK || ($_smarty_tpl->tpl_vars['foo']->value->menuLINK == '' && $_smarty_tpl->tpl_vars['active']->value == 'init')) {?>active<?php }?>" >

                   		<a href="<?php echo base_url();
echo $_smarty_tpl->tpl_vars['foo']->value->menuLINK;?>
" onclick="closenav();">

                   			<?php echo $_smarty_tpl->tpl_vars['foo']->value->menuNAME;?>


                   		</a>

                   </li>

                 <?php
$_smarty_tpl->tpl_vars['foo'] = $__foreach_foo_0_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                </ul>

            </div>

            <!-- /.navbar-collapse -->

        </div>

        <!-- /.container -->

    </nav>

<?php }
}

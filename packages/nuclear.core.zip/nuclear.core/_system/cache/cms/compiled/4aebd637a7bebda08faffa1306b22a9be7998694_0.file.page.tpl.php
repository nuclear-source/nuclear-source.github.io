<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 01:12:46
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms-nodb\themes\default\partials\page.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576726eeddb2c2_10082621',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4aebd637a7bebda08faffa1306b22a9be7998694' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms-nodb\\themes\\default\\partials\\page.tpl',
      1 => 1465957307,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576726eeddb2c2_10082621 (Smarty_Internal_Template $_smarty_tpl) {
?>
<header class="intro-header" style="background-image: url('<?php echo base_url();?>
nc-content/uploads/lg/<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesIMG;?>
')">

	<div class="filter" >     

 		 <div class="container">

          	<div class="row">

                <div class="col-lg-12">

                    <div class="post-heading text-center" >

                        <h1 class="color1">- <?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTITLE;?>
 - </h1>

                        <h2 class="subheading color0"  > <?php echo $_smarty_tpl->tpl_vars['content']->value->pagesSUBTITLE;?>
</h2>

                    </div>

                </div>

            </div>       

         </div>   

     </div>

</header>

<section class="header bg1 color0">

     <div class="container">

	        <div class="row"> <div class="col-xs-9"></div>

	        	<div class="col-md-3">

	            	<div id="custom-search-input">

	               		 <div class="input-group col-md-12">

	                  			 <input type="text" class="form-control input-sm" placeholder="Procurar" />

	                   			 <span class="input-group-btn">

	                       			 <button class="btn btn-info btn-sm" type="button">

	                        		    <i class="glyphicon glyphicon-search"></i>

	                     		   </button>

	                   			 </span>

	                	</div>

	           		 </div>

	        	</div>       

	      </div>

	 </div>

</section>

<section class="content container">

		<div class="row">

			<div class="col-xs-12">

				<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


			</div>

			<div class="col-xs-12">			

				<div class='list-group gallery '>

				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['content']->value->galery, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_1_saved = $_smarty_tpl->tpl_vars['val'];
?>

					<div class="col-sm-3 col-xs-6 nowrap ">

						<a href="<?php echo base_url();?>
nc-content/uploads/lg/<?php echo $_smarty_tpl->tpl_vars['val']->value;?>
" class=" fancybox" rel="ligthbox" >	

							<div class="overlayu" style="height:200px;"><i class="fa fa-search" ></i></div>			

							<div class="image" style="background-image:url('<?php echo base_url();
echo NUCLEARCONTENT;?>
/uploads/md/<?php echo $_smarty_tpl->tpl_vars['val']->value;?>
');"></div>

						</a>	

					</div>

				<?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_1_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

				</div>

			</div>

		</div>

</section><?php }
}

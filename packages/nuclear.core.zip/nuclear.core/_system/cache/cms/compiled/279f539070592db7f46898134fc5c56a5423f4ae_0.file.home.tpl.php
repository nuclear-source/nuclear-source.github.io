<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 01:12:14
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms-nodb\themes\pereira\partials\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_576726ce5ee976_01625985',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '279f539070592db7f46898134fc5c56a5423f4ae' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms-nodb\\themes\\pereira\\partials\\home.tpl',
      1 => 1466376481,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576726ce5ee976_01625985 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="container-fluid wow fadeIn"  data-wow-duration="1.3s"  data-wow-delay="0.7s"  style="margin:0px;padding:0px;">

	<div class="parallax-window"  data-position-y="center" data-parallax="scroll" data-image-src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
lg/<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesIMG;?>
">

		<div class="container" style="padding-top:120px;COLOR:#fff;font-size:24px">

		

		<div class="row">

		<div class="col-sm-12" style="text-align:center;color:#fff;font-weight:100">

		<br/><br/>

		<img src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
xs/logotipos/logotipo__date__1460690393.PNG" height="80px" />

			<div style="clear:both"><h1>Ferragens e Acessórios para Casa e Jardim</h1>

			<br/>

			</div>

			<a class="btn btn-default wow fadeInLeft  bg1 color0"  data-wow-duration="1s"  data-wow-delay="0.7s"   href="<?php echo base_url();?>
catalogo/">VER CATÁLOGO</a>

			<div style="clear:both">

			<br/>

			</div>

		</div>

		

		</div>

	</div>

</section>

<section style="background:#202021;">

	<div class="container">

		<div class="row"><br/>

		<div class="col-xs-12"><p style="font-weight:200;font-size:22px;text-transform:uppercase;color:#fff;border-bottom:1px solid #e44f2a;text-align:center;">Conheça a nossa gama de produtos</p></div>

		  <?php $_smarty_tpl->_assignInScope('categories', get_categories());
?>

                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['categories']->value, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_1_saved = $_smarty_tpl->tpl_vars['val'];
?>

                 <div class="col-sm-3 col-xs-6 ober"  style="margin:0px;padding:3px;ext-align:center;">

					

					<a href="<?php echo base_url();?>
catalogo/<?php echo $_smarty_tpl->tpl_vars['val']->value->groupsSLUG;?>
" class=" fancybox" rel="ligthbox" >	

					<div class="over2 overlayu" style="height:200px;"><i class="fa fa-search" ></i></div>			

					<div style="background-image:url('<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
md/<?php echo $_smarty_tpl->tpl_vars['val']->value->groupsIMG;?>
');width:100%;background-size:cover; background-position:center center;height:200px;"></div>				

					</a>	<div style="clear:both"></div>

					<a href="" class="btn btn-default btn-arteantiga" ><?php echo $_smarty_tpl->tpl_vars['val']->value->groupsTITLE;?>
</a>

				</div>

                 <?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_1_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

	

		

		</div><div style="clear:both"><br/><br/><br/></div>

	</div>

</section>

<section>

	<div class="container">

		<div class="row">

		<?php echo $_smarty_tpl->tpl_vars['content']->value->pagesTEXT;?>


	</div>

</section><?php }
}

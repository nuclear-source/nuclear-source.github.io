<?php
/* Smarty version 3.1.30-dev/51, created on 2016-06-20 00:41:45
  from "X:\xampp\htdocs\_dev2\nuclear\v0.02\public_html\..\.nuclear\..\.src\_cms\themes\default\components\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30-dev/51',
  'unifunc' => 'content_57671fa9e6a898_35919452',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f090d22e8c50118748e2d0311dd28fb05e2873ce' => 
    array (
      0 => 'X:\\xampp\\htdocs\\_dev2\\nuclear\\v0.02\\public_html\\..\\.nuclear\\..\\.src\\_cms\\themes\\default\\components\\footer.tpl',
      1 => 1466376104,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57671fa9e6a898_35919452 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section class="footer" >

    <div class="container" >

		<div class="row">         

			<div class="col-md-3 md-margin-bottom-40" >

				<a  href="{ base_url()}"><img src="<?php echo $_smarty_tpl->tpl_vars['uploads']->value;?>
sm/<?php echo $_smarty_tpl->tpl_vars['project']->value['logotipo'];?>
" width="100%"></a>

        		<address class="md-margin-bottom-40" >

	        		<b><?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
</b><br/>

					<?php echo $_smarty_tpl->tpl_vars['project']->value['description'];?>
<br/>

				</address>

            </div>

			<div class="col-md-5" >

				<h5 >Links-rápidos</h5>

				<hr class="break"/>

                <div class="col-md-12 nowrap md-margin-bottom-40" >

	                <?php if (isset($_smarty_tpl->tpl_vars['pages']->value)) {?>

	                	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['pages']->value, 'val', false, 'fokey');
foreach ($_from as $_smarty_tpl->tpl_vars['fokey']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->_loop = true;
$__foreach_val_1_saved = $_smarty_tpl->tpl_vars['val'];
?>

							<a href="<?php echo base_url();?>
page/<?php echo $_smarty_tpl->tpl_vars['val']->value->pagesSLUG;?>
" >

			            	<?php echo $_smarty_tpl->tpl_vars['val']->value->pagesTITLE;?>
</a>

			            	<br>

						<?php
$_smarty_tpl->tpl_vars['val'] = $__foreach_val_1_saved;
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

						<a href="<?php echo $_smarty_tpl->tpl_vars['project']->value['facebook'];?>
" ><?php echo $_smarty_tpl->tpl_vars['project']->value['facebook'];?>
</a><br>

					<?php }?>              

				</div>

			</div>

			<div class="col-md-4" >

				<h5>Contactos</h5>

				<hr class="break"/>

				<div class="col-md-12 nowrap md-margin-bottom-40"   >

                   <?php echo $_smarty_tpl->tpl_vars['project']->value['address'];?>
<br/>	

				   <?php echo $_smarty_tpl->tpl_vars['project']->value['CEP'];?>
 - <?php echo $_smarty_tpl->tpl_vars['project']->value['city'];?>
<br/> 

				   <?php echo $_smarty_tpl->tpl_vars['project']->value['country'];?>
<br/>								

				   <b>Telefone:</b> <?php echo $_smarty_tpl->tpl_vars['project']->value['phone1'];?>
<br/>

				   <b>Telemóvel:</b> <?php echo $_smarty_tpl->tpl_vars['project']->value['phone2'];?>
<br/>

				   <b>Fax:</b> <?php echo $_smarty_tpl->tpl_vars['project']->value['fax'];?>
<br/>

				   <b>Email:</b> <?php echo $_smarty_tpl->tpl_vars['project']->value['email'];?>


                </div>

			</div>

         </div>

      </div>

</section>      

<footer class="copyright">

     <div class="container">

         <div class="row">

              <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">

	                <p style="color:#140b04;text-align:center" >

	                	<?php echo $_smarty_tpl->tpl_vars['project']->value['title'];?>
 &copy;<?php echo date("Y",time());?>


	                	<b>Developed by: </b>

	                	<a href="http:///www.joelferreira.eu" target="_blank">Joel Ferreira</a> 

	                 </p>

              </div>

         </div>

    </div>

    <p id="back-top2" >

		<a href="#top">

			<span  class="shadow"><i class="fa fa-arrow-up" style="margin-bottom:6px"></i> <br/>TOP</span>

		</a>

	</p>

</footer>

    

    



    <?php }
}

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 * NUCLEAR CMS v0.1
 * @author webmaster@nuclearcms.com
 * www.nuclearCMS.com
 *
 */
class Nuclear_crud extends Nuclear_model
{
	protected $table='';
	protected $prefix='';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('objects_helper');
	}
	/**
	 * Define TABLE;
	 * @param string $table
	 */
	function table($table='')
	{
		$this->table=$table;
	}
	
	/**
	 * INSERT line
	 * @param string $data
	 * @return insert_id
	 */
	function create($data='')
	{
		$this->db->insert($this->table, $data);
		$insert_id = $this->db->insert_id();
		return  $insert_id;
	}
	
	/**
	 * READ lines
	 * @param string $select
	 * @param array $where
	 * @param array $order
	 * @param string $limit
	 * @return lines
	 */
	function read($select='*',$where=array(),$order=array(),$limit='')
	{
		
		$this->db->select($select);
		if(count($where)>0){
			foreach($where as $key=>$value)
				$this->db->where($key,$value);
		}
		if(count($order)>0){
			foreach($order as $key=>$value)
				$this->db->order_by($key,$value);
		}
		
		if($limit!=''){
			$this->db->limit($limit);
		}
		return $this->db->get($this->table)->result();
		
	}
	
	/**
	 * 
	 * UPDATE LINES
	 * @param array $data
	 * @param array $where
	 * @return affected_rows
	 */
	function update($data=array(),$where=array())
	{
		if(count($where)>0){
			foreach($where as $key=>$value)
				$this->db->where($key,$value);
		}
		$this->db->update($this->table, $data);
		return $this->db->affected_rows();
	}
	/**
	 * DELETE LINES
	 * @param array $where
	 * @return affected_rows
	 */
	function delete($where=array())
	{
		if(count($where)>0){
			foreach($where as $key=>$value)
				$this->db->where($key,$value);
		}
		$this->db->delete($this->table);
		return $this->db->affected_rows();
	}
	
}
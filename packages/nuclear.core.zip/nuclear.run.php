<?php defined('INDEXPATH') OR exit('No direct script access allowed');
/**********
 * RUN NUCLEAR MUDULES
 * **********/
$apps=array();
 	//DEBUG APPS
	if (isset($config['appMODULES']) && is_dir(INDEXPATH.'/'.$config['appMODULES']) && $handle = opendir(INDEXPATH.'/'.$config['appMODULES'])) {
		$FOLDER = $config['appMODULES'].'/';
		while (false !== ($entry = readdir($handle))) {
			if(is_dir(INDEXPATH.'/'.$FOLDER.$entry) && $entry!='.' && $entry!='..' && $entry!=$path_to_nuclear  && $entry!=$FOLDER)
					$apps[$entry]=$entry; }
		closedir($handle);
	}
	//IF NO APPS 	2- tem pasta vazia
	if(!isset($apps) || (isset($apps) && is_array($apps) && count($apps)==0)){
		if(!is_dir(INDEXPATH.'/'.$path_to_nuclear.$appFOLDER)){
			echo 'NuclearCMS - Run::DEFAULT (line16) - ';die();}
		else
			$default=true;
	}
	//IF HAS APPS 3- tem pastas 
	else{
		
	
		if(is_dir(INDEXPATH.$config['appMODULES'].'/'.$appFOLDER)){
			
			$content_path=$config['appMODULES'].'/'.$appFOLDER;
			$public_core=$config['appMODULES'].'/'.$appFOLDER;
			
			}
		//ERRO 4- tem pasta mas não tem default;	
		else if(isset($FORCE))
			{echo 'NuclearCMS - Run::APP  (line33) -';die();}
		//IF NOT FORCE IGNORE ERROR
		else{
			$default=true;	
		}
	}
	
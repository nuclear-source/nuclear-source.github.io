<?php defined('INDEXPATH') OR exit('No direct script access allowed');
/**********
 * RUN NUCLEAR MUDULES
 * **********/
//IF force == show error if not src or not src default
if(isset($src) && isset($force) && (!is_dir(__DIR__.'/'.$src) || !is_dir(__DIR__.'/'.$src.'/'.$appFOLDER)) ){
	echo 'NuclearCMS - Run::SRC  (line7) -';die();}	
//ELSEIF have src && default app;
if (isset($src) && is_dir(__DIR__.'/'.$src) && is_dir(__DIR__.'/'.$src.'/'.$appFOLDER))
{
	$apps=array();
	$handle = opendir(__DIR__.'/'.$src);
	while (false !== ($entry = readdir($handle))) {
			if(is_dir(__DIR__.'/'.$src.'/'.$entry) && $entry!='.' && $entry!='..' && $entry!=$path_to_nuclear  && $entry!=$src.'/')
				$apps[$entry]=$entry; 
	}
	if(count($apps)==1)
		$defaultsrc=true;	
}
else
	$default=true;


<?php defined('INDEXPATH') OR exit('No direct script access allowed');

//IF NOT DEFAULT
if(!isset($default))
{
	require_once "system.func.php";
	$return = return_uri();
	
	if(count($apps)>0 && isset($return['uri'][0]) && $return['uri'][0]!='')
	{
		foreach($apps as $app)
		{
			if($return['uri'][0] == $app  )
			{
				define('PRIVATENAME', $app);
				$public_core='_apps/'.$app;
				$content_path='_apps/'.$app;
				$app_name=$app;
			}
		}
	}
	echo 'não default criar modules debugs';exit();
}
else
{
	define('ISDEFAULT',true);
	$public_core  =$path_to_nuclear.$appFOLDER;
	$content_path =$path_to_nuclear.$appFOLDER;
	$app_name     =$appDEFAULT;
}


$framework = 'Codeigniter';
defined('PRIVATENAME') or define('PRIVATENAME', '');


define('APPNAME',      $appDEFAULT);
define('NUCLEARCORE',  $public_core);
define('NUCLEARCONTENT', $content_path);
define('NCPATH', INDEXPATH.'/');
define('VENDORPATH', str_replace($inc,'',__DIR__.'/').'_vendor'.DIRECTORY_SEPARATOR);
require_once "system.autoload.php";
<?php

//System-config
$inc         = ".system/";
$src         = "";
$srcpublic   = "";
$srcadmin    = "private";
$config      = "config.php";
$appPREFIX   = "core";
$force       = true;

//App-config
$appDEFAULT  = "client";  
$appVERSION  = "development";


if(isset($src) && isset($force) && (is_dir($self.$src) && is_file($self.$src.$config)))
	require_once($self.$src.$config);
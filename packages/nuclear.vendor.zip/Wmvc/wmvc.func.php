<?php 
defined('INDEXPATH') OR exit('No direct script access allowed');
function return_uri()
{	
	$uri =array(); 
	$public_request =array();
	$public=array();
	$www='';
	$return=array();
	$application= array_reverse(explode(DIRECTORY_SEPARATOR,$_SERVER['SCRIPT_FILENAME']));
	if(count($application)==1){$application= array_reverse(explode('/',$_SERVER['SCRIPT_FILENAME']));}
	unset($application[0]);
	$request= explode('/',$_SERVER['REQUEST_URI']);
	foreach($application as $key=>$val)
	{
		foreach($request as $key2=>$val2){
			if($val==$val2){
				$appi[$key]=$val;
				unset($request[$key2]);
			}
			else{
				unset($application[$key]);
			}
		}
	}
	$uri = array_values(array_filter($request));
	$return['uri']=$uri;
	$return['public']=$public;
	$return['www']=$www;
	return $return;
}
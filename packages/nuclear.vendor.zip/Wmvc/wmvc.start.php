<?php defined('INDEXPATH') OR exit('No direct script access allowed');

//IF NOT DEFAULT
$realpath = getcwd();
$rootpath = $self;
$src_folder = $src;
$nuclear_path = $rootpath.$inc;
$realsrc  = $self.$src;
if(!isset($default) && !isset($defaultsrc))
{

	require_once $func;
	$return = return_uri();
	if(!isset($return['uri'][0]))
		$defaultsrc=true;
	else{
		//CONFIRMA QUE É ALIAS
		
		if(isset($alias[$return['uri'][0]]))
		{	
			if(is_dir($realsrc.$appPREFIX.'_'.$alias[$return['uri'][0]])){
				$app_name = $alias[$return['uri'][0]];
				$appFOLDER = $appPREFIX.'_'.$app_name.'/';
				define('PRIVATENAME', $return['uri'][0]);
				define('PRIVATEPATH', $appFOLDER);
				$public_core  =$realsrc.$appFOLDER;
				$content_path =$realsrc.$appFOLDER;
				
			}
			else if(is_dir(str_replace($srcpublic,$srcadmin,$realsrc).$appPREFIX.'_'.$alias[$return['uri'][0]])){
				$realsrc=str_replace($srcpublic,$srcadmin,$realsrc);
			
				$app_name = $alias[$return['uri'][0]];
				$appFOLDER = $appPREFIX.'_'.$app_name.'/';
				define('PRIVATENAME', $return['uri'][0]);
				define('PRIVATEPATH', $appFOLDER);
				$public_core  =$realsrc.$appFOLDER;
				$content_path =$realsrc.$appFOLDER;
			}
			else
				$defaultsrc=true;
			
		}
		else 
			$defaultsrc=true;
	}
	if(isset($defaultsrc))
		define('ISDEFAULT',true);
}
////////////////////////////
else
	define('ISDEFAULT',true);

if(defined('ISDEFAULT'))
{
	$app_name     =$appDEFAULT;
	
	

	if(isset($defaultsrc) && is_dir($realsrc. $appPREFIX.'_'.$app_name)){
		$appFOLDER = $appPREFIX.'_'.$app_name.'/';
		$public_core  =$realsrc.$appFOLDER;
		$content_path =$realsrc.$appFOLDER;	
	}
	else{
		$public_core  =$self."vendor/Default";
		$content_path =$self."vendor/Default";
	}
}
if (in_array($app_name, $private))
	defined('PRIVE') or define('PRIVE', TRUE);
else
	defined('PRIVE') or define('PRIVE', FALSE);
defined('PRIVATENAME') or define('PRIVATENAME', '');
define('APPNAME',      $app_name);
define('NUCLEARCORE',  $public_core);
define('NUCLEARCONTENT', $content_path);

define('NCPATH', INDEXPATH.'/');
define('VENDORPATH', $self.$vendorpath."/");
define('SRCPATH', $realsrc);
///////////
$real_system = str_replace($core,'',__DIR__.'/');

require_once VENDORPATH."Codeigniter/index.php";




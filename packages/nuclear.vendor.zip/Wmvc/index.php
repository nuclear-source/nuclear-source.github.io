<?php

$self      = ROOTPATH;
$compile   = '.config.php';
$start     = 'wmvc.start.php';
$func      = 'wmvc.func.php';
$run       = 'wmvc.run.php';
$framework = 'Codeigniter';

/**
 * BOOT FRAMEWORK
 * ****************************************/

if(is_file(__DIR__.'/'.$compile)) 
    require_once(__DIR__.'/'.$compile);
else
    {echo 'error:boostrap:config_compile.file (line:19)';die();}
/**
 * RUN FRAMEWORK
 * ****************************************/
if(isset($src)) 
	require_once __DIR__.'/'.$run;
else 
	$default=true;  
/**
 * START SYSTEM
 * ****************************************/
require_once __DIR__.'/'.$start;
<?php defined('INDEXPATH') OR exit('No direct script access allowed');


/**
 * ERRO:IF:FORCE
 * **********************************/
if(isset($src) && isset($force) && ((!is_dir($self.$src) 
|| !is_dir($self.$src.$appPREFIX.'_'.$appDEFAULT))) && (!is_dir($self.str_replace($srcpublic,$srcadmin,$src)) 
|| !is_dir($self.str_replace($srcpublic,$srcadmin,$src).$appPREFIX.'_'.$appDEFAULT)) )
	{
		echo 'NuclearCMS - Run::SRC  (line7) -';
		die();
	} 
	
	

/**
 * DEFAULT:IF:NO-FORCE
 * ***********************************/
if(!is_dir($self.$src.$appPREFIX.'_'.$appDEFAULT) && is_dir($self.str_replace($srcpublic,$srcadmin,$src).$appPREFIX.'_'.$appDEFAULT)) 
	$src= str_replace($srcpublic,$srcadmin,$src);
 

if (!isset($src) && !is_dir($self.$src))
	$default=true;
	
/**
 * APPS:RUN
 * ***********************************/
else	
{
	$apps=array();	
	$handle = opendir($self.$src);
	while (false !== ($entry = readdir($handle))) {
	
			if(is_dir($self.$src.$entry) && $entry!='.' && $entry!='..' && $entry!=$src.'/' 
			     && strpos($entry, $appPREFIX)!==false && $entry!=getcwd()   )
				$apps[$entry]=$entry; 
	}
	if(count($apps)==1)
		$defaultsrc=true;
	else if(count($apps)==0)
		$default=true;	
	
}

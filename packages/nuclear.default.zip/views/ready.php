<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="pt"  ><!--<![endif]-->
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>NUCLEARcms Ready</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
     <style>
     	body
     	{
     		background:#eaeaea
     	}
     	h2
     	{
     		background:#fff;
	     	border:1px solid #ccc;
	     	margin:0 auto;
	     	width:100%;
	     	max-width:500px;
	     	text-align:center;
	     	font-family:"Roboto","Helvetica","Verdana","Arial","sans-serif";
     	}
     </style>
</head>
<body >
<h2 style=""><B>NUCLEAR</B>cms is READY!!!</h2>
</body>
</html>

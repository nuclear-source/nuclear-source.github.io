<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$autoload['config'] = array();
$autoload['libraries'] = array();
$autoload['helper'] = array();
/////////////////////////////////////
$autoload['packages'] = array();
$autoload['drivers'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
